const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const requestIp = require('request-ip');
const fs = require('fs');
const path = require('path');
const checkIpAccess = require('./src/whitelist');

const updateJson = require('./jsonOp/Update');

const bannerJson = require('./jsonOp/Banner');

const topupJson = require('./jsonOp/Topup');

const blacklistJson = require('./jsonOp/blacklist');

const blockmodsJson = require('./jsonOp/blockmods');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'your_jwt_secret'; // Change this to your own secret keys
const IP_ADDRESS = '0.0.0.0'; // Listen on all available IPv4 addresses

app.use(requestIp.mw());


app.use(checkIpAccess);

// Middleware
app.use(bodyParser.json());

const allowedIPs = ['192.168.1.219', '59.103.60.155'];

// MongoDB setup
mongoose.connect('mongodb+srv://kingawaimerkhan:r0wKO3suA5Y3nPhQ@cluster0.avdrcok.mongodb.net/mydatabase?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    console.log('Connected to MongoDB');
});

const payload1 = {
    clz: 0,
    resVersion: 0,
    ever: 10039,
    targetId: 684656624,
    name: ".ThatOneGreen.",
    pioneer: true,
    rid: 8008
};

const secretKey1 = 'your_secret_key1';
const token1 = jwt.sign(payload1, secretKey1);

const equippedAvatarSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    avatarId: {
        type: String,
        required: true
    },
    avatarTypeId: {
        type: String,
        required: true
    },
    avatarCamera: {
        type: String,
        required: true
    },
    avatarName: {
        type: String,
        required: true
    },
    avatarIconUrl: {
        type: String,
        required: true
    },
    avatarResourceId: {
        type: String,
        required: true
    },
    avatarDetails: {
        type: String,
        required: true
    },
    avatarPrice: {
        type: Number,
        required: false
    },
     avatarCurrency: {
        type: Number,
        required: false
    }
});

const friendSchema = new mongoose.Schema({
    userId: String,
    nickName: String,
    picUrl: String,
    sex: Number,
    vip: Number,
    onlineStatus: { type: Number, default: 0 },
    language: { type: String, default: 'default' },
    country: { type: String, default: 'default' },
    status: { type: Number, default: 0 },
    friendFor: String // Save the friend for the user in headers
});

// Friend Model
const Friend = mongoose.model('Friend', friendSchema);

const shopSchema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  database: String,
  price: Number,
  currency: Number
});


// Avatar Model
const Shop = mongoose.model('Shop', shopSchema);

const gameserviceSchema = new mongoose.Schema({
  serviceUrl: String,
  download: String
});

// Avatar Model
const Gameservice = mongoose.model('Gameservice', gameserviceSchema);

const EquippedAvatar = mongoose.model('EquippedAvatar', equippedAvatarSchema);

// Avatar Schema
const avatarSchema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number
});

// Avatar Model
const Avatar = mongoose.model('Avatar', avatarSchema);

const transactionSchema = new mongoose.Schema({
orderId: String,
                userId: String,
                currency: Number,
                qty: Number,
                inoutType: Number,
                transactionType: Number,
                description: String,
                status: Number,
                price: Number,
                type: Number,
                balance: Number,
                created:  { type: Date, default: Date.now }
});


// Avatar Model
const Transaction = mongoose.model('Transaction', transactionSchema);

const avatar5Schema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number
});

// Avatar Model
const Avatar5 = mongoose.model('Avatar5', avatar5Schema);

const avatar4Schema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number
});

// Avatar Model
const Avatar4 = mongoose.model('Avatar4', avatar4Schema);

const avatar3Schema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number
});

// Avatar Model
const Avatar3 = mongoose.model('Avatar3', avatar3Schema);



const avatar2Schema = new mongoose.Schema({
  id: Number,
  typeId: Number,
  camera: String,
  name: String,
  iconUrl: String,
  resourceId: String,
  details: String,
  forId: Number,
  price: Number,
  currency: Number
});

// Avatar Model
const Avatar2 = mongoose.model('Avatar2', avatar2Schema);
// Schema and model for user registration
const userSchema = new mongoose.Schema({
    username: String,
    password: String,
    nickname: String,
    userId: String,
    accessToken: String,
    birthday: String,
    introduction: String,
    currency: Number,
    diamonds: Number,
    gold: Number,
    gDiamonds: Number,
    sex: Number,
    picUrl: String,
    vip: Number,
    colorfulname: String,
    clanName: String,
    clanId: Number,
    clanRole: Number,
    firstNickName: String,
    experience: Number
});

const User = mongoose.model('User', userSchema);

const clanDBSchema = new mongoose.Schema({
    clanId: Number,
    ownerId: String, // Added ownerId field
    name: String,
    headPic: String,
    tags: Array,
    details: String,
    experience: Number,
    level: Number,
    role: Number,
    freeVerify: Number,
    region: String,
    lmaololq: String,
    chiefName: String,
    memberCount: Number,
    maxCount: Number,
    currentCount: Number,
    chiefId: Number,
    maxExperience: Number
});

// Define the ClanDB model
const ClanDB = mongoose.model('ClanDB', clanDBSchema);

const gameSchema = new mongoose.Schema({
    gameId: String,
    gameTitle: String,
    gameCoverPic: String,
    visitorEnter: Number,
    praiseNumber: Number
});

// Define the ClanDB model
const Game = mongoose.model('Game', gameSchema);

const stopServiceSchema = new mongoose.Schema({
    id: String,
    title: String,
    isShow: String,
    isShowInGame: String,
    content: String
});

// Define the ClanDB model
const stopService = mongoose.model('stopService', stopServiceSchema);

const systemServiceSchema = new mongoose.Schema({
    id: String,
    title: String,
    isShow: String,
    isShowInGame: String,
    content: String,
    updateTime: String
});

// Define the ClanDB model
const systemService = mongoose.model('systemService', systemServiceSchema);

const gameDataq = {
    "code": 1,
    "message": "SUCCESS",
    "data": {
        "pageNo": 0,
        "pageSize": 8,
        "totalPage": 2,
        "totalSize": 1,
        "data": [
            {
                "gameId": "g1008",
                "gameTitle": "Bed Wars",
                "gameCoverPic": "https://cdn.discordapp.com/icons/1229895585780469871/397e7323dc3d1e0dc10d472d38fdce42.webp?size=2048",
                "visitorEnter": 1,
                "praiseNumber": 363.0
            },
            {
                "gameId": "g2077",
                "gameTitle": "Build At Sea",
                "gameCoverPic": "http://static.sandboxol.com/sandbox/games/images/g2034-1614337880064.png",
                "visitorEnter": 0,
                "praiseNumber": 0
            }
       ]
    },
    "other": null
};

const users = [
    { id: 1, username: 'example_user', password: 'old_password' }
];

const friendRequestSchema = new mongoose.Schema({
    requestId: String,
    userId: String,
    forId: String,
    msg: String,
    status: Number,
    sentFrom: String
});

const FriendRequest = mongoose.model('FriendRequest', friendRequestSchema);

const mailSchema = new mongoose.Schema({
    id: { type: String, required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    status: { type: Number, default: 2 },
    type: { type: Number, default: 0 },
    attachment: String,
    extra: String,
    sendDate: { type: Date, default: Date.now },
    userId: String
});

const Mail = mongoose.model('Mail', mailSchema);
app.post('/user/api/v1/app/set-password', async (req, res) => {
    const { password, userId } = req.body;
    const userIdentity = req.headers.userid;
    const accessToken = req.headers['access-token']; // Corrected header name

    // Check if userIdentity and accessToken are provided
    if (!userIdentity || !accessToken) {
        return res.status(400).json({ message: 'UserIdentity and Access-Token headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userIdentity) {
                return res.status(403).json({ message: 'Access-Token does not match userIdentity.' });
            }

            // Find the user by userId
            let user = await User.findOne({ userId });

            // If user not found, return error
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Set the password
            user.password = password;

            // Save the user
            await user.save();

            // Return success response
            return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
        });
    } catch (err) {
        // Handle errors
        console.error('Error setting password:', err);
        res.status(500).json({ message: 'Error setting password.', error: err });
    }
});

// Renew endpoint
app.post('/user/api/v1/app/renew', async (req, res) => {
    const { account, password, nick } = req.body;
   
    // Generate random userId
    const userId = (Math.floor(Math.random() * 100000) + 600000).toString();

    // Create a new user
    const user = new User({ userId });

    try {
        // Save the user
        await user.save();

        // Generate an access token
        const accessToken = jwt.sign({ userId }, JWT_SECRET);

        // Return success response with userId and accessToken
        res.status(200).json({ code: 1, message: 'SUCCESS', data: { userId, accessToken } });
    } catch (err) {
        // Handle errors
        console.error('Error registering user:', err);
        res.status(500).json({ message: 'Error registering user.', error: err });
    }
});
// Registration endpoint
app.post('/user/api/v1/user/register', async (req, res) => {
    const { nickName, sex } = req.body;
    const userId = req.headers.userid;
    // Check if username is provided
    if (!nickName) {
        return res.status(400).json({ message: 'Nickname is required.' });
    }

    try {
        // Assuming userIdentity is the correct header to use
        let user = await User.findOne({ userId: userId });

        // If user not found, return error
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
const existingUser = await User.findOne({ nickname: nickName });
    if (existingUser) {
        return res.status(400).json({ code: 7, message: 'Nickname already exists choose other nickname', data: 'null' });
    }


        // Check if username already exists
        // Generate random numeric user ID and random nickname as needed

        // Save user to database with additional data
        user.nickname = nickName;
        user.sex = sex;
       user.userId = userId;
        user.picUrl = '';
        // Assuminuser.password is defined somewhere
        user.birthday = '';
        user.diamonds = 0;
        user.gDiamonds = 0;
        user.details = '';
        user.gold = 0;
        user.vip = 0;
        user.clanId = 0;
        user.clanrole = 0;
        user.clanName =  'null';
        user.firstNickName =  'true';
        user.clanRole =  0;
        user.experience =  0;

        await user.save();

        // Build the response data separately
        const responseData = { 
            userId: userId,
            nickName: user.nickname,
            sex: user.sex, 
            picUrl: user.picUrl, 
            details: user.details, 
            birthday: user.birthday,
            vip: user.vip, 
            expire: 0
        };

        // Include the response data in the main response
        res.status(200).json({ 
            code: 1, 
            message: 'SUCCESS', 
            data: { 
            userId: userId,
            nickName: user.nickname,
            sex: user.sex, 
            picUrl: user.picUrl, 
            details: user.details, 
            birthday: user.birthday,
            vip: user.vip, 
            expire: 0
        } 
        });
    } catch (error) {
        res.status(500).json({ message: 'Error registering user.', error: error });
    }
});

// Login endpoint
app.post('/user/api/v1/app/login', async (req, res) => {
    const { uid, password } = req.body;

    // Check if uid is provided
    if (!uid) {
        return res.status(400).json({ message: 'User ID or username is required.' });
    }

    try {
        // Check if uid is a valid user ID
        let user = await User.findOne({ userId: uid });

        // If uid is not a valid user ID, check if it's a valid username
        if (!user) {
            user = await User.findOne({ username: uid });
        }

        // If user does not exist, return error
        if (!user) {
            return res.status(200).json({
             code: 102,
             message: 'User ID or username not found.',
             data: 'null'
          });
        }

        // Check if password is correct
        if (user.password !== password) {
            return res.status(200).json({
             code: 108,
             message: 'Incorrect password.',
             data: 'null'
          });
        }

        // Generate a new access token
        const accessToken = jwt.sign({ userId: user.userId }, JWT_SECRET);

        // Return success response with user ID, access token, telephone, and email
        res.status(200).json({
            code: 1,
            data: {
                userId: user.userId,
                accessToken: accessToken,
                telephone: '',
                email: ''
            },
           message: 'SUCCESS'
        });
    } catch (err) {
        console.error('Error logging in:', err);
        res.status(500).json({ message: 'Error logging in.' });
    }
});
// Sample protected endpoint

app.post('/user/api/v2/app/login', async (req, res) => {
    const { uid, password } = req.body;

    // Check if uid is provided
    if (!uid) {
        return res.status(400).json({ message: 'User ID or username is required.' });
    }

    try {
        // Check if uid is a valid user ID
        let user = await User.findOne({ userId: uid });

        // If uid is not a valid user ID, check if it's a valid username
        if (!user) {
            user = await User.findOne({ username: uid });
        }

        // If user does not exist, return error
        if (!user) {
            return res.status(404).json({
             code: 7,
             message: 'User ID or username not found.',
             data: 'null'
          });
        }

        // Check if password is correct
        if (user.password !== password) {
            return res.status(401).json({
             code: 6,
             message: 'Incorrect password.',
             data: 'null'
          });
        }

        // Generate a new access token
        const accessToken = jwt.sign({ userId: user.userId }, JWT_SECRET);

        // Return success response with user ID, access token, telephone, and email
        res.status(200).json({
            code: 1,
            data: {
                userId: user.userId,
                accessToken: accessToken,
                telephone: '',
                email: ''
            },
           message: 'SUCCESS'
        });
    } catch (err) {
        console.error('Error logging in:', err);
        res.status(500).json({ message: 'Error logging in.' });
    }
});

app.put('/shop/api/v1/shop/decorations/buy', async (req, res) => {
    const { decorationIds } = req.query;
    const { userId } = req.headers;

    // Fetch user from database to check currency
    const user = await User.findOne({ userId });

    // Check if user found
    if (!user) {
        return res.status(404).json({ message: 'User not found.' });
    }

    // Check if the user has enough currency for each decoration
    for (const decorationId of decorationIds) { // Assuming decorationIds is an array
        // Fetch decoration details from AvatarEvery collection
        const decoration = await AvatarEvery.findOne({ id: decorationId });

        // Check if decoration found
        if (!decoration) {
            return res.status(404).json({ message: 'Decoration not found.' });
        }

        // Check if user has enough currency
        if (user.currency < decoration.price) {
            const currencyName = decoration.currency === 1 ? 'diamonds' : 'gold';
            return res.status(500).json({ message: `Insufficient ${currencyName}.` });
        }

        // Deduct currency from user
        user.currency -= decoration.price;
    }

    // Update user's currency in the database
    await user.save();

    // Add purchased decorations to user's inventory
    for (const decorationId of decorationIds) { // Assuming decorationIds is an array
        // Fetch decoration details from AvatarEvery collection
        const decoration = await AvatarEvery.findOne({ id: decorationId });

        // Check if decoration found
        if (!decoration) {
            return res.status(404).json({ message: 'Decoration not found.' });
        }

        // Fetch the avatar database where the decoration should be saved
        const avatarDatabase = await AvatarEvery.findOne({ database: decoration.database });

        // Check if the avatarDatabase exists
        if (!avatarDatabase) {
            return res.status(404).json({ message: 'Avatar database not found.' });
        }

        // Save the decoration to the specified database
        avatarDatabase.decorations.push({
            id: decoration.id,
            typeId: decoration.typeId,
            camera: decoration.camera,
            name: decoration.name,
            iconUrl: decoration.iconUrl,
            resourceId: decoration.resourceId,
            details: decoration.details,
            forId: userId,
            price: decoration.price,
            currency: decoration.currency
        });

        await avatarDatabase.save();
    }

    res.status(200).json({ message: 'Decorations purchased successfully.' });
});

app.put('/user/api/v1/user/nickName', async (req, res) => {
    const userId = req.headers.userid;
    const accessToken = req.headers['access-token']; // Corrected header name

    try {
        const { newName, oldName } = req.query;

        // Fetch user from database
        const user = await User.findOne({ userId });

        // Check if user found
        if (!user) {
            return res.status(404).json({ message: 'User not found.', data: null, other: null });
        }

        // Check if firstNickName is 'true'
        if (user.firstNickName === 'true') {
            // Change the nickname for free
            // Check if newName already exists for another user
            const existingUserWithNewName = await User.findOne({ nickname: newName });
            if (existingUserWithNewName) {
                return res.status(200).json({ code: 1003, message: 'NickName exist', data: null, other: null });
            }

            // Replace oldName with newName in user document
            user.nickname = newName;

            // Set firstNickName to 'false'
            user.firstNickName = 'false';
        } else {
            // Check if user has enough diamonds
            if (user.diamonds < 50) {
                return res.status(200).json({ code: 5006, message: 'Diamonds insufficient', data: null, other: null });
            }

            // Deduct 50 diamonds from user
            user.diamonds -= 50;

            // Check if newName already exists for another user
            const existingUserWithNewName = await User.findOne({ nickname: newName });
            if (existingUserWithNewName) {
                return res.status(200).json({ code: 1003, message: 'NickName exist', data: null, other: null });
            }

            // Replace oldName with newName in user document
            user.nickname = newName;
        }

        // Save updated user document
        await user.save();

        // Construct success response
        const successResponse = {
    code: 1,
    message: 'SUCCESS',
    data: {
        nickName: user.nickname,
        picUrl: user.picUrl,
        birthday: user.birthday,
        details: user.details,
        sex: user.sex,
        vip: user.vip
    },
    other: null
};

        res.status(200).json(successResponse);
    } catch (error) {
        console.error('Error processing request:', error);
        res.status(500).json({ message: 'Internal server error.' });
    }
});

// Add friend request
// Get friend requests
app.get('/friend/api/v1/friends/requests', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Find friend requests for the user
            const friendRequests = await FriendRequest.find({ forId: userId });

            // Calculate total size of friend requests
            const totalSize = friendRequests.length;

            // Set pageSize to 20 and totalPage to Math.ceil(totalSize / pageSize)
            const pageSize = 20;
            const totalPage = Math.ceil(totalSize / pageSize);

            // Extract query parameters
            const { pageNo = 0 } = req.query;

            // Fetch details of the senders from the user database
            const requestData = await Promise.all(friendRequests.slice(pageNo * pageSize, (parseInt(pageNo) + 1) * pageSize).map(async (request) => {
                // Find sender details from the user database
                const sender = await User.findOne({ userId: request.sentFrom });

                // Default values for sender details if not found
                const senderDetails = {
                    requestId: request.requestId,
                    nickname: '',
                    picUrl: 'http://default-pic-url.com/default.jpg',
                    userId: request.sentFrom,
                    sex: 0, // Assuming default sex is 0
                    vip: 0, // Assuming default vip is 0
                };

                // Replace sender details with actual details if found in the database
                if (sender) {
                    senderDetails.nickname = sender.nickname;
                    senderDetails.picUrl = sender.picUrl;
                    senderDetails.sex = sender.sex || senderDetails.sex;
                    senderDetails.vip = sender.vip || senderDetails.vip;
                }

                // Construct request data
                return {
                    requestId: senderDetails.requestId,
                    userId: senderDetails.userId,
                    msg: request.msg || "Let's be friends",
                    status: request.status  || 0,
                    nickName: senderDetails.nickname,
                    picUrl: senderDetails.picUrl,
                    vip: senderDetails.vip,
                    sex: senderDetails.sex,
                    age: 0, // Assuming age is not available in the sender's details
                    country: 'IT', // Assuming country is not available in the sender's details
                    language: 'en', // Assuming language is not available in the sender's details
                    onlineStatus: 0, // Assuming online status is not available in the sender's details
                };
            }));

            // Construct the response
            const responseData = {
                pageNo: parseInt(pageNo),
                pageSize: pageSize,
                totalPage: totalPage,
                totalSize: totalSize,
                data: requestData,
            };

            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (error) {
        console.error('Error fetching friend requests:', error);
        res.status(500).json({ message: 'Error fetching friend requests.' });
    }
});

app.get('/clan/api/v1/clan/tribe', async (req, res) => {
    // Extracting clanId from query parameter
    const clanId = req.query.clanId;

    // Check if clanId is provided
    if (!clanId) {
        return res.status(400).json({ message: 'clanId query parameter is required.' });
    }

    try {
        // Search for users in userdb with the given clanId and roles 15 or 20
        const clanMembers = await User.find({ clanId: clanId, clanRole: { $in: [15, 20] } });

        // Search for clan in clandb with the given clanId
        const clan = await ClanDB.findOne({ clanId: clanId });

        // If clan not found, return error
        if (!clan) {
            return res.status(404).json({ message: 'Clan not found with the provided clanId.' });
        }

        // Prepare the response with clan information and clan members
        const clanMembersResponse = clanMembers.map(member => ({
            userId: member.userId,
            role: member.role,
            headPic: member.headPic,
            nickName: member.nickName,
            colorfulNickName: null,
            avatarFrame: "frame_bronze.png",
        }));

        // Prepare the response with clan information and clan members
        const responseData = {
            clanId: clan.clanId,
            name: clan.name,
            headPic: clan.headPic,
            tags: clan.tags,
            details: clan.details,
            experience: clan.experience,
            level: clan.level,
            currentCount: clan.currentCount,
            maxCount: clan.maxCount,
            clanMembers: clanMembersResponse,
            freeVerify: clan.freeVerify,
            region: clan.region
        };

        // Sending the success response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
    } catch (err) {
        console.error('Error retrieving clan info:', err);
        res.status(500).json({ message: 'Error retrieving clan info.' });
    }
});
app.get('/config/files/blockymods-banner', (req, res) => {
    // Sample game data for g1014
        
    // Sending the response
    res.json(bannerJson);
});

// Method to accept friend request
// Method to accept friend request
app.post('/friend/api/v1/accept', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const friendFor = req.body.friendId; // Save the friend for the friendId in the request body

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if friendId is provided in the request body
            const friendId = req.body.friendId;
            if (!friendId) {
                return res.status(400).json({ message: 'FriendId is required in the request body.' });
            }

            // Find the friend in the user database
            const friendUser = await User.findOne({ userId: friendId });

            // If friend not found, return error
            if (!friendUser) {
                return res.status(404).json({ code: 7, message: 'User not found.', data: null });
            }

            // Find the user who initiated the friend request
            const userWhoRequested = await User.findOne({ userId });

            // If user not found, return error
            if (!userWhoRequested) {
                return res.status(404).json({ code: 7, message: 'User who requested not found.', data: null });
            }

            // Create a new friend document for the user who initiated the request
            const newUserFriend = new Friend({
                userId: userId,
                nickName: userWhoRequested.nickname || '',
                picUrl: userWhoRequested.picUrl || '',
                sex: userWhoRequested.sex || 0,
                vip: userWhoRequested.vip || 0,
                friendFor: friendId // Save the friend for the friendId in the request body
            });

            // Save the friend for the user who initiated the request to the database
            await newUserFriend.save();

            // Create a new friend document for the user who accepted the request
            const newFriend = new Friend({
                userId: friendUser.userId,
                nickName: friendUser.nickname || '',
                picUrl: friendUser.picUrl || '',
                sex: friendUser.sex || 0,
                vip: friendUser.vip || 0,
                friendFor: userId // Save the friend for the user who initiated the request
            });

            // Save the friend for the user who accepted the request to the database
            await newFriend.save();

            res.status(200).json({ code: 1, message: 'Friend added successfully.', data: newFriend });
        });
    } catch (error) {
        console.error('Error accepting friend request:', error);
        res.status(500).json({ message: 'Error accepting friend request.' });
    }
});

// Sample protected endpoint
app.get('/inner/api/v1/database/details', async (req, res) => {
    const userId = req.headers['userid'];

    // Check if userId header is provided
    if (!userId) {
        return res.status(400).json({ code: 1, message: 'userId header is required.', data: 'null' });
    }

    try {
        // Fetch user information from the database based on userId
        let user = await User.findOne({ userId });

        // If user not found, create a new user

        // Customize the response with required user information
        const userInfo = {
            userId: user.userId,
            nickName: user.nickname || '',
            account: user.username || '',
            gDiamonds: user.gDiamonds || 0,
            diamonds: user.diamonds || 0,
            gold: user.gold || 0,
            coins: user.currency || 0,
            colorfulNickName: user.colorfulname,
            picUrl: user.picUrl || 'http://staticgs.sandboxol.com/sandbox/avatar/1707674835816832.jpg',
            password: user.password || '',
        };

        res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
    } catch (err) {
        console.error('Error retrieving user info:', err);
        res.status(500).json({ message: 'Error retrieving user info.' });
    }
});

// List of allowed IP addresses

app.get('/pay/api/v1/pay/products', (req, res) => {
    // Sample game data for g1014
        
    // Sending the response
    res.json(topupJson);
});

// Add friend request
app.post('/friend/api/v1/friends', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { friendId, msg } = req.body;

    // Check if Access-Token, userId, and friendId are provided
    if (!accessToken || !userId || !friendId) {
        return res.status(400).json({ message: 'Access-Token, userId, and friendId are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the friend ID exists in the user database
            const friendUser = await User.findOne({ userId: friendId });

            if (!friendUser) {
                return res.status(400).json({ code: 7, message: 'User fake', data: null });
            }
const requestId = (Math.floor(Math.random() * 100000) + 600000).toString();
            // Set default message if empty
            const message = msg ? msg : "Let's be friends";

            // Create a new friend request
            const newFriendRequest = new FriendRequest({
                requestId: requestId,
                userId: userId,
                forId: friendId,
                msg: message,
                status: 0,
                sentFrom: userId
            });

            // Save the friend request to the database
            await newFriendRequest.save();

            res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
        });
    } catch (error) {
        console.error('Error adding friend request:', error);
        res.status(500).json({ message: 'Error adding friend request.' });
    }
});

app.get('/user/api/v1/user/nickName/free', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if userId and accessToken are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ code: 5006, message: 'userId and access-token headers are required.', data: null });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ code: 5006, message: 'Invalid Access-Token.', data: null });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ code: 5006, message: 'Access-Token does not match userId.', data: null });
            }

            // Find user in database
            const user = await User.findOne({ userId });

            // Check if user exists
            if (!user) {
                return res.status(404).json({ code: 5006, message: 'User not found.', data: null });
            }

            // Check if firstNickName is true
            if (user.firstNickName) {
                // Return free nickname details
                return res.status(200).json({
                    code: 1,
                    message: 'SUCCESS',
                    data: {
                        free: user.firstNickName,
                        currency: 0,
                        quantity: 50
                    }
                });
            } else {
                // Return details with cost
                return res.status(200).json({
                    code: 1,
                    message: 'SUCCESS',
                    data: {
                        free: user.firstNickName,
                        currency: 1,
                        quantity: 50
                    }
                });
            }
        });
    } catch (error) {
        console.error('Error checking nickname availability:', error);
        res.status(500).json({ code: 5006, message: 'Error checking nickname availability.', data: null });
    }
});

app.post('/user/api/v1/addKeyValue', async (req, res) => {
    try {
        const { key, value } = req.body;

        // Check if key and value are provided
        if (!key || !value) {
            return res.status(400).json({ message: 'Key and value are required.' });
        }

        // Fetch all users from the database
        const users = await User.find();

        // Iterate over each user document and add the key-value pair
        await Promise.all(users.map(async (user) => {
            // Add key-value pair to user document
            user[key] = value;
            // Save updated user document
            await user.save();
        }));

        res.status(200).json({ message: 'Key-value pair added to all users.' });
    } catch (error) {
        console.error('Error adding key-value pair:', error);
        res.status(500).json({ message: 'Error adding key-value pair.' });
    }
});

app.put('/friend/api/v1/friends/:friendId/agreement', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const friendId = req.params.friendId; // Extracting friendId from URL parameters

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Find the friend request in the database based on userId and friendId
            const friendRequest = await FriendRequest.findOne({ forId: userId, sentFrom: friendId });

            // If friend request not found, return error
            if (!friendRequest) {
                return res.status(404).json({ code: 7, message: 'Friend request not found.', data: null });
            }

            // Update the status of the friend request to accepted (status: 1)
            friendRequest.status = 1;

            // Save the updated friend request status to the database
            await friendRequest.save();

            // Find user info of the friend who initiated the request
            const userWhoRequested = await User.findOne({ userId: friendId });

            // If user not found, return error
            if (!userWhoRequested) {
                return res.status(404).json({ code: 7, message: 'User not found.', data: null });
            }

            // Create a new friend document for the user who initiated the request
            const newUserFriend = new Friend({
                userId: friendId,
                nickName: userWhoRequested.nickname || '',
                picUrl: userWhoRequested.picUrl || '',
                sex: userWhoRequested.sex || 0,
                vip: userWhoRequested.vip || 0,
                friendFor: userId // Save the friend for the friendId in the request body
            });

            // Save the friend for the user who initiated the request to the database
            await newUserFriend.save();

            // Find user info of the user who accepted the request
            const userWhoAccepted = await User.findOne({ userId });

            // If user not found, return error
            if (!userWhoAccepted) {
                return res.status(404).json({ code: 7, message: 'User not found.', data: null });
            }

            // Create a new friend document for the user who accepted the request
            const newFriend = new Friend({
                userId: userId,
                nickName: userWhoAccepted.nickname || '',
                picUrl: userWhoAccepted.picUrl || '',
                sex: userWhoAccepted.sex || 0,
                vip: userWhoAccepted.vip || 0,
                friendFor: friendId // Save the friend for the user who initiated the request
            });

            // Save the friend for the user who accepted the request to the database
            await newFriend.save();

            res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
        });
    } catch (error) {
        console.error('Error updating friend request:', error);
        res.status(500).json({ message: 'Error updating friend request.' });
    }
});

// Method to get friends list
app.get('/friend/api/v1/friends', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userid headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Extract query parameters
            const { pageNo = 0, pageSize = 200 } = req.query;

            // Find friends for the user
            const friendList = await Friend.find({ friendFor: userId })
                .limit(parseInt(pageSize))
                .skip(parseInt(pageSize) * parseInt(pageNo));

            // Get total size by counting friends for the user
            const totalSize = await Friend.countDocuments({ friendFor: userId });

            // Construct data array with friend details
            const data = await Promise.all(friendList.map(async (friend) => {
                // Find friend details from the user database
                const friendUser = await User.findOne({ userId: friend.userId });

                // Check if friendUser exists
                if (!friendUser) {
                    console.error('User not found for friend:', friend);
                    // Handle the case where friendUser is not found, maybe return an error response
                    return null;
                }

                // Extract necessary details from the friend user
                const friendDetails = {
                    userId: friendUser.userId || '888888888',
                    nickName: friendUser.nickname || '',
                    picUrl: friendUser.picUrl || '',
                    picType: friendUser.picType || 0,
                    decorationPicUrl: friendUser.decorationPicUrl || '',
                    alias: friendUser.alias || null,
                    status: friendUser.status || 0,
                    gameId: friendUser.gameId || null,
                    partyInfo: friendUser.partyInfo || null,
                    vip: friendUser.vip || 0,
                    expireDate: friendUser.expireDate || null,
                    sex: friendUser.sex || 0,
                    details: friendUser.details || '',
                    clanId: friendUser.clanId || 0,
                    clanName: friendUser.clanName || '',
                    role: friendUser.role || 0,
                    userGameDataResponse: friendUser.userGameDataResponse || null,
                    age: friendUser.age || 0,
                    country: friendUser.country || '',
                    language: friendUser.language || '',
                    logoutTime: friendUser.logoutTime || null,
                    colorfulNickName: friendUser.colorfulNickName || null,
                    avatarFrame: friendUser.avatarFrame || null,
                    userLevel: friendUser.userLevel || 0,
                    levelPic: friendUser.levelPic || null,
                    birthday: friendUser.birthday || '',
                    region: friendUser.region || '',
                    regionCode: friendUser.regionCode || 0,
                    regionCreateTime: friendUser.regionCreateTime || null,
                    gameName: friendUser.gameName || null,
                    vipLv: friendUser.vipLv || 0,
                    vipExp: friendUser.vipExp || 0,
                    vipMaxExp: friendUser.vipMaxExp || 0,
                    vipIcon: friendUser.vipIcon || null,
                    showUrl: friendUser.showUrl || '',
                    memberType: friendUser.memberType || null,
                    memberName: friendUser.memberName || null,
                    ownerType: friendUser.ownerType || null,
                    ownerName: friendUser.ownerName || null,
                    recruitInfo: friendUser.recruitInfo || null,
                    familyTagList: friendUser.familyTagList || null,
                    onlyTag: friendUser.onlyTag || null,
                    family: friendUser.family || false,
                    suitExhibitionList: friendUser.suitExhibitionList || null,
                    personalityItems: friendUser.personalityItems || {},
                    friend: true
                };

                return friendDetails;
            }));

            // Remove null elements from data array
            const filteredData = data.filter(item => item !== null);

            // Construct response
            const response = {
                pageNo: parseInt(pageNo),
                pageSize: parseInt(pageSize),
                totalPage: Math.ceil(totalSize / parseInt(pageSize)),
                totalSize: totalSize,
                data: filteredData
            };

            res.status(200).json({ code: 1, message: 'SUCCESS', data: response });
        });
    } catch (error) {
        console.error('Error fetching friends list:', error);
        res.status(500).json({ message: 'Error fetching friends list.' });
    }
});



app.put('/mailbox/api/v1/mail', async (req, res) => {
    try {
        const userId = req.headers['userid'];
        const accessToken = req.headers['access-token'];
        const status = req.query.status;
        const ids = req.query.ids;

        // Check if Access-Token and userId headers are provided
        if (!accessToken || !userId) {
            return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
        }

app.put('/friend/api/v1/friends/:friendId/rejection', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const friendId = req.params.friendId; // Extracting friendId from URL parameters

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Find the friend request in the database based on userId and friendId
            const friendRequest = await FriendRequest.findOne({ forId: userId, sentFrom: friendId });

            // If friend request not found, return error
            if (!friendRequest) {
                return res.status(404).json({ code: 7, message: 'Friend request not found.', data: null });
            }

            // Update the status of the friend request to declined (status: 2)
            friendRequest.status = 2;

            // Save the updated friend request status to the database
            await friendRequest.save();

            res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
        });
    } catch (error) {
        console.error('Error rejecting friend request:', error);
        res.status(500).json({ message: 'Error rejecting friend request.' });
    }
});

        // Check if status is set to 3
        if (status !== '3') {
            return res.status(400).json({ message: 'Status must be set to 3.' });
        }

        // Check if ids query parameter is provided
        if (!ids) {
            return res.status(400).json({ message: 'Ids query parameter is required.' });
        }

        // Convert ids to array if it's a single value
        const mailIds = Array.isArray(ids) ? ids : [ids];

        // Find and delete mails matching the provided ids and userId
        const deleteResults = await Mail.deleteMany({ id: { $in: mailIds }, userId: userId });

        // Check if any mails were deleted
        if (deleteResults.deletedCount === 0) {
            return res.status(404).json({ message: 'No matching mails found for deletion.' });
        }

        // Return success response
        return res.status(200).json({ code: 1, message: 'SUCCESS', data: null });
    } catch (error) {
        console.error('Error deleting mail:', error);
        return res.status(500).json({ message: 'Error deleting mail.' });
    }
});

// API endpoint to retrieve password, ID, and username of every registered account
app.get('/user/api/v1/accounts', async (req, res) => {
    try {
        // Query the database to retrieve all user documents
        const accounts = await User.find({}, { password: 1, userId: 1, username: 1, _id: 0 });

        // Check if there are no registered accounts
        if (accounts.length === 0) {
            return res.status(404).json({ message: 'No registered accounts found.' });
        }

        // Return the array of user documents containing password, ID, and username
        res.json({ accounts });
    } catch (err) {
        console.error('Error retrieving accounts:', err);
        res.status(500).json({ message: 'Error retrieving accounts.' });
    }
});

// API endpoint to retrieve client's IP address
app.get('/api/clientip', (req, res) => {
    const CLIENT_IP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    res.json({ success: true, data: { clientIP: CLIENT_IP } });
});


app.get('/game/api/v1/games/stop/announcement/info', async (req, res) => {
    try {
        // Check if stopService isShow is true
        const gameservice = await stopService.findOne();


        // If stopService isShow is true, construct the response with necessary data
        const gameData = {
            "code": 1,
            "message": "SUCCESS",
            "data": {
                "id": gameservice.id,
                "content": gameservice.content,
                "title": gameservice.title,
                "isShow": gameservice.isShow,
                "isShowInGame": false
            },
            "other": null
        };

        // Sending the response
        res.json(gameData);
    } catch (error) {
        // If an error occurs, handle it and return 500 error
        console.error("Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


app.get('/game/api/v1/games/announcement/info', async (req, res) => {
    try {
        // Check if systemService isShow is true
        const gameservice = await systemService.findOne();

        if (!gameservice) {
            return res.status(404).json({ error: "Game service not found" });
        }

        // Construct the response with necessary data
        const gameData = {
            "code": 1,
            "message": "SUCCESS",
            "data": {
                "id": gameservice.id,
                "content": gameservice.content,
                "title": gameservice.title,
                "isShow": gameservice.isShow,
                "isShowInGame": false,
                "updateTime": gameservice.updateTime
            },
            "other": null
        };

        // Sending the response
        res.json(gameData);
    } catch (error) {
        // If an error occurs, handle it and return 500 error
        console.error("Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});
app.get('/activity/api/v1/activity/notice', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "SUCCESS",
  "data": {
    "goldFree": 0,
    "diamondFree": 0,
    "integralReward": 0
  },
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/blockymods-chest-banner', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "OK",
  "data": [
    {
      "image": "http://static.sandboxol.com/sandbox/activity/banner/bg_chest_banner_one_0126.png",
      "title": ""
    },
    {
      "image": "http://static.sandboxol.com/sandbox/activity/banner/bg_chest_banner_two_0126.png",
      "title": ""
    },
    {
      "image": "http://static.sandboxol.com/sandbox/activity/banner/bg_chest_banner_three_0126.png",
      "title": ""
    }
  ],
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/blockymods-activity-logo', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "OK",
  "data": {
    "redPointLogo": "http://static.sandboxol.com/sandbox/activity/chest/ic_chest_red_point_logo.gif",
    "normalLogo": "http://static.sandboxol.com/sandbox/activity/chest/ic_chest_logo.gif"
  },
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/game/api/v1/games/app-engine/upgrade', async (req, res) => {
    try {
        // Sample game data for g1014
        let gameservice = await Gameservice.findOne();

        if (!gameservice) {
            return res.status(404).json({ error: "Gameservice not found" });
        }

        const gameData = {
            "code": 1,
            "message": "success",
            "data": {
                "downloadUrl": gameservice.download,
                "hash": "7a939afec272726d5b060e57d8a2ea69",
                "resVersion": 10039,
                "needUpgrade": true
            },
            "other": null
        };

        // Sending the response
        res.json(gameData);
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/decoration/api/v2/decorations/5', async (req, res) => {
  
const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }
  
  try {
    // Fetch all avatars from the database
    let avatars = await Avatar5.find();

    // Map the fetched avatars to the desid sponse format
    const responseData = avatars.map(avatar => ({
      id: avatar.id,
      typeId: avatar.typeId,
      camera: avatar.camera,
      name: avatar.name,
      iconUrl: avatar.iconUrl,
      status: 0,
      sex: 0,
      tag: [],
      resourceId: avatar.resourceId,
      details: avatar.details,
      expi: 0,
      type: 0,
      clanLevel: 0,
      vip: 0,
      occupyPosition: [12]
    }));

    res.status(200).json({
                code: 1,
                message: 'SUCCESS',
        data: responseData,
        other: null
            });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

app.get('/game/api/v1/games/update/tip/info/app/:gameId', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "SUCCESS",
  "data": null,
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

const token = jwt.sign(payload1, secretKey1);


app.get('/game/api/v2/game/auth', async (req, res) => {
    try {
        // Sample game data for g1014
        let gameservice = await Gameservice.findOne();

        if (!gameservice) {
            return res.status(404).json({ error: "Gameservice not found" });
        }

        const gameData = {
            "code": 1,
            "message": "OK",
            "data": {
                "token": null, // No token needed
                "signature": "063c182f519e24d49daac2c02e9e65eadd5e5534",
                "timestamp": 1713287579940,
                "region": 8008,
                "dispUrl": gameservice.serviceUrl,
                "engineType": "v1",
                "country": "PK"
            },
            "other": null
        };

        // Sending the response
        res.json(gameData);
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.post('/v1/dispatch', (req, res) => {
    // Sample game data for g1014
    const gameData = {
        "code": 1,
        "message": "success",
        "data": {
            "gaddr": "192.168.0.109:8080",
            "name": ".ThatOneGreen.",
            "mid": "m1401",
            "mname": "g1014.1706090787451",
            "downurl": "http://staticgs.sandboxol.com/sandbox/games/maps/g1014.1706090787451.zip",
            "region": 8008,
            "resVersion": 0,
            "requestIds": {
                "684656624": "cofb3afke5g2uashmhbg"
            },
            "gameType": "g1014",
            "cdns": [
                {
                    "cdnId": "1",
                    "cdnName": "",
                    "cdnUrl": "staticgs.sandboxol.com",
                    "url": "http://staticgs.sandboxol.com/sandbox/games/maps/g1014.1706090787451.zip",
                    "ratio": 1,
                    "base": true
                }
            ],
            "retry": false
        }
    };

    // Sending the response
    res.json(gameData);
});

app.get('/user/api/v1/users/:userId/daily/sign/in', (req, res) => {
    // Sample game data for g1014
    const gameData = {
        "code": 1,
        "message": null,
        "data": {
            "sixth": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
                "quantity": 200,
                "type": "gold",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            },
            "third": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/cube.png",
                "quantity": 3,
                "type": "diamond",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            },
            "seventh": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/cube.png",
                "quantity": 7,
                "type": "diamond",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            },
            "fifth": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
                "quantity": 150,
                "type": "gold",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            },
            "fourth": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
                "quantity": 100,
                "type": "gold",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            },
            "first": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
                "quantity": 100,
                "type": "gold",
                "name": null,
                "id": 0,
                "status": 1,
                "adQuantity": 0,
                "adType": null
            },
            "second": {
                "url": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
                "quantity": 150,
                "type": "gold",
                "name": null,
                "id": 0,
                "status": 0,
                "adQuantity": 0,
                "adType": null
            }
        },
        "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.put('/user/api/v1/users/:userId/daily/sign/in', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ code: 0, message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ code: 0, message: 'Access-Token does not match userId.' });
            }

            // Assuming you have a function to get the user from the database based on userId
            let user = await User.findOne({ userId });

            if (!user) {
                return res.status(404).json({ code: 0, message: 'User not found.' });
            }

            // Update user's balance
            user.gold += 100; // Assuming diamonds reward quantity is always 2

            // Save the updated user
            await user.save();

            // Return success response with updated balances
            res.status(200).json({ code: 1, message: 'success', data: 115978648, other: null });
        });
    } catch (err) {
        console.error('Error giving rewards:', err);
        res.status(500).json({ code: 0, message: 'Error giving rewards.' });
    }
});

app.get('/clan/api/v1/clan/tribe/bulletin', async (req, res) => {
    // Extracting userId and accessToken from headers
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userId and accessToken are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'userId and accessToken headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if decoded userId matches the one in headers
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, return error
            if (!user) {
                return res.status(404).json({ code: 1, message: 'SUCCESS', data: null, other: null });
            }
            // Fetch clan information based on user's clanId
            let clan = await ClanDB.findOne({ clanId: user.clanId });

            // If clan not found, return error
            if (!clan) {
                return res.status(404).json({ code: 7006, message: 'not join tribe', data: null, other: null });
            }

            // Prepare the response with clan information
            const responseData = {
                content: clan.lmaololq,
                updateTime: 999999999
            };

            // Sending the success response
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
        });
    } catch (err) {
        console.error('Error retrieving clan info:', err);
        res.status(500).json({ message: 'Error retrieving clan info.' });
    }
});

app.get('/pay/api/v1/wealth/record/users/:lmaololq', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId are required.' });
    }

    try {
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ code: 0, message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ code: 0, message: 'Access-Token does not match userId.' });
            }

            // Query the game database to find recommended games
            const transaction = await Transaction.findOne({ userId: userId }); // Adjust the query based on your database schema

            // Prepare the response data
            const responseData = transaction.map(transaction => ({
            orderId: transaction.orderId,
                userId: transaction.userId,
                currency: transaction.currency,
                qty: transaction.qty,
                inoutType: transaction.inoutType,
                transactionType: transaction.transactionType,
                description: transaction.description,
                status: transaction.status,
                price: transaction.price,
                type: transaction.type,
                balance: transaction.balance,
                created: transaction.created
        }));


            // Return the search results with fixed values for pageNo, pageSize, totalPage, and totalSize
            res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo: 0, // Fixed value
                    pageSize: responseData.length, // Adjust pageSize based on the number of transactions returned
                    totalPage: 2, // Fixed value
                    totalSize: 0, // Adjust totalSize based on the number of transactions returned
                    data: responseData,
                    other: null
                }
            });
        });
    } catch (error) {
        console.error('Error searching for recommended games:', error);
        res.status(500).json({ message: 'Error searching for recommended games.' });
    }
});

app.get('/clan/api/v1/clan/tribe/member', async (req, res) => {
    // Extracting userId from headers
    const userId = req.headers['userid'];

    // Check if userId is provided
    if (!userId) {
        return res.status(400).json({ message: 'userid header is required.' });
    }

    try {
        // Search for the user in userdb based on userId from headers
        const user = await User.findOne({ userId: userId });

        // If user not found, return error
        if (!user) {
            return res.status(404).json({ message: 'User not found with the provided userId.' });
        }

        // Search for other users in userdb with the same clanId as the user in headers,
        // sorted by experience in descending order
        const clanMembers = await User.find({ clanId: user.clanId }).sort({ experience: -1 });
                    const totalSize = clanMembers.length

            // Set pageSize to 20 and totalPage to Math.ceil(totalSize / pageSize)
            const pageSize = 20;
            const totalPage = Math.ceil(totalSize / pageSize);

            // Extract query parameters
            const { pageNo = 0 } = req.query;
        // Prepare the response with clan members information
        const responseData = clanMembers.map(member => ({
            userId: member.userId,
            nickName: member.nickname,
            headPic: member.picUrl,
            status: 30,
            vip: member.vip || 0,
            expireDate: "",
            role: member.clanRole,
            experience: member.experience
        }));

const lmaololq = {
                pageNo: parseInt(pageNo),
                pageSize: pageSize,
                totalPage: totalPage,
                totalSize: totalSize,
                data: responseData
            };

        // Sending the success response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
    } catch (err) {
        console.error('Error retrieving clan members:', err);
        res.status(500).json({ message: 'Error retrieving clan members.' });
    }
});

app.get('/friend/api/v2/friends/:userId', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { userId: searchUserId } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Query the database for the user by userId
            const user = await User.findOne({ userId: searchUserId });

            // Check if the user exists
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }
            // Prepare the response
            const responseData = {
                userId: user.userId,
                nickName: user.nickname,
                picUrl: user.picUrl || '', // Assuming picUrl is optional in the user model
                picType: 0,
                decorationPicUrl: null,
                alias: null,
                status: 30,
                gameId: null,
                partyInfo: null,
                vip: user.vip || 0,
                expireDate: null,
                sex: user.sex || '2',
                details: user.introduction,
                clanId: user.clanId  || 0,
                clanName: user.clanName  || null,
                role: user.clanRole  || 0,
                userGameDataResponse: null,
                age: 0,
                country: null,
                language: "en",
                logoutTime: 0,
                colorfulNickName: user.colorful,
                avatarFrame: null,
                userLevel: 1,
                levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
                birthday: "",
                region: null,
                regionCode: 0,
                regionCreateTime: 1624972168000,
                gameName: null,
                vipLv: 0,
                vipExp: 0,
                vipMaxExp: 0,
                vipIcon: null,
                showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
                memberType: null,
                memberName: null,
                ownerType: null,
                ownerName: null,
                recruitInfo: null,
                familyTagList: null,
                onlyTag: null,
                family: false,
                suitExhibitionList: null,
                personalityItems: {
                    nameplate: "vip_nameplate_0.png"
                },
                friend: false
            };

            // Return the user data
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (err) {
        console.error('Error searching for user:', err);
        res.status(500).json({ message: 'Error searching for user.' });
    }
});


// API endpoint to delete a user account by ID
// Define the route to delete a user account by ID
app.delete('/user/api/v1/accounts', async (req, res) => {
    const { userId } = req.body; // Extract user ID from request body

    try {
        // Check if the user ID is provided in the request body
        if (!userId) {
            return res.status(400).json({ message: 'User ID is required in the request body.' });
        }

        // Find the user account in the database
        const user = await User.findOne({ userId });

        // Check if the user exists
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        // Delete the user account from the database
        await User.deleteOne({ userId });

        // Return success response
        res.json({ message: 'User account deleted successfully.' });
    } catch (error) {
        console.error('Error deleting user account:', error);
        res.status(500).json({ message: 'Error deleting user account.' });
    }
});


// API to set introduction by user ID
// API to update introduction by user ID from headers
app.put('/inner/api/v1/introduction', async (req, res) => {
    const { introduction } = req.body;
    const userId = req.headers.userid;

    try {
        // Update the user's introduction in the database
        await User.updateOne({ userId }, { introduction });

        res.json({ message: 'Introduction updated successfully.' });
    } catch (error) {
        console.error('Error updating introduction:', error);
        res.status(500).json({ message: 'Error updating introduction.' });
    }
});



// API to update birthday by user ID from headers
app.put('/inner/api/v1/birthday', async (req, res) => {
    const { birthday } = req.body;
    const userId = req.headers.userid;

    try {
        // Update the user's birthday in the database
        await User.updateOne({ userId }, { birthday });

        res.json({ message: 'Birthday updated successfully.' });
    } catch (error) {
        console.error('Error updating birthday:', error);
        res.status(500).json({ message: 'Error updating birthday.' });
    }
});
// API to show user information by user ID from headers
app.get('/inner/api/v1/showinfo', async (req, res) => {
    const userId = req.headers.userid;

    try {
        // Find the user in the database
        const user = await User.findOne({ userId });
        // Check if the user exists
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        // Construct response data
        const responseData = {
            birthday: user.birthday ? user.birthday : 'Not set',
            introduction: user.introduction ? user.introduction : 'Not set',
            currency: user.currency ? user.currency : 'Not set'
        };

        // Return success response with user info
        res.json({ code: 1, message: 'Success', data: responseData });
    } catch (error) {
        console.error('Error retrieving user info:', error);
        res.status(500).json({ message: 'Error retrieving user info.' });
    }
});

app.post('/inner/api/v1/register', async (req, res) => {
    const { account, password, customUserId } = req.body;

    // Check if username and customUserId are provided
    if (!account || !customUserId) {
        return res.status(400).json({ message: 'Username and custom user ID are required.' });
    }

    // Check if username already exists
    const existingUser = await User.findOne({ username: account });
    if (existingUser) {
        return res.status(400).json({ message: 'User already exists.' });
    }

    // Check if custom user ID already exists
    const existingCustomUserId = await User.findOne({ userId: customUserId });
    if (existingCustomUserId) {
        return res.status(400).json({ message: 'Custom user ID already exists.' });
    }

    // Generate random nickname
    const nicknames = ['CoolPlayer', 'GameMaster', 'EpicGamer', 'NinjaPlayer']; // Add more nicknames as needed
    const nickname = nicknames[Math.floor(Math.random() * nicknames.length)];

    // Save user to database
    const user = new User({ username: account, password, nickname, userId: customUserId });
    try {
        await user.save();
        const accessToken = jwt.sign({ userId: customUserId }, JWT_SECRET);
        res.status(200).json({ code: 1, message: 'SUCCESS', data: { userId: customUserId, accessToken } });
    } catch (err) {
        res.status(500).json({ message: 'Error registering user.', error: err });
    }
});



app.get('/notice/api/v1/server-notice/config', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "SUCCESS",
  "data": null,
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/blockmods-config-v1', (req, res) => {
    // Sample game data for g1014
    // Sending the response
    res.json(blockmodsJson);
});

app.get('/user/api/v1/audit/service/isAuditService', (req, res) => {
    // Sample game data for g1014
    const gameData = {
    "code": 1,
    "data": {
    "flag": false,
    "httpUrl": null,
    "httpsUrl": null
  }
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/blockymods-check-version', (req, res) => {
    // Sample game data for g1014
        
    // Sending the response
    res.json(updateJson);
});

app.get('/game/api/v2/games/:gameid', (req, res) => {
    const { gameid } = req.params;

    // Construct path to the JSON file based on gameid
    const filePath = path.join(__dirname, 'gameDetails', `${gameid}.json`);

    // Check if the file exists
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            console.error(err);
            res.status(404).json({ error: 'Game data not found' });
            return;
        }

        // Read the JSON file
        fs.readFile(filePath, 'utf8', (readErr, data) => {
            if (readErr) {
                console.error(readErr);
                res.status(500).json({ error: 'Internal server error' });
                return;
            }

            try {
                const gameData = JSON.parse(data);
                res.json(gameData);
            } catch (parseError) {
                console.error(parseError);
                res.status(500).json({ error: 'Error parsing game data' });
            }
        });
    });
});

app.delete('/api/deleteDocuments', async (req, res) => {
    try {
        // Get the database
        const db = client.db(dbName);

        // Delete documents with a specific password
        const result = await db.collection('users').deleteMany({ password: 'gay991' });

        // Check if any documents were deleted
        if (result.deletedCount > 0) {
            res.status(200).json({ message: `${result.deletedCount} documents deleted successfully.` });
        } else {
            res.status(404).json({ message: 'No documents found with the specified password.' });
        }
    } catch (error) {
        console.error('Error deleting documents:', error);
        res.status(500).json({ message: 'Error deleting documents.' });
    }
});
    // Sending the response
    // Sending the response                                    res.json(gameData);                                    });
app.post('/user/api/v1/user/details/info', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, create a new user
            if (!user) {
                user = new User({ userId });
                await user.save();
            }

            // Customize the response with required user information
            const userInfo = {
                userId: user.userId,
                sex: user.sex || 2,
                nickName: user.nickname || '', // Use empty string if nickname is not set
                birthday: user.birthday || '', // Use empty string if birthday is not set
                details: user.introduction || '', // Use empty string if introduction is not set
                currency: user.currency || 0, // Default to 0 if currency is not set
                diamonds: user.diamonds || 0, // Default to 0 if diamonds is not set
                golds: user.gold || 0, // Default to 0 if gold is not set
                gDiamonds: user.gDiamonds || 0, // Default to 0 if gDiamonds is not set
                picUrl: user.picUrl  || 'http://staticgs.sandboxol.com/sandbox/avatar/1707674835816832.jpg',
                picType: 0,
                telephone: null,
                account: user.username || '',
                hasPassword: true,
                hasCuboCustomPassword: true,
                platform: "google",
                official: 0,
                money: 0.0,
                starCode: "star",
                colorfulNickName: user.colorfulname,
                avatarFrame: null,
                isNewUser: 0,
                isNewDevice: 0,
                userLevel: 1,
                vip: user.vip  || 0,
                levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
                regionCode: 7,
                region: "SG",
                cuboOpenId: "50cf435cb1aeea67f0b84bc57a66f3a3",
                accountType: "google",
                deviceRegisterTime: null,
                country: "PK",
                language: "en",
                showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
                sandboxUser: 2,
                suitExhibitionCount: 0,
                monthCardList: null,
                personalityItems: {
                    nameplate: "vip_nameplate_1.png"
                },
                vipLv: 1,
                vipExp: 100,
                vipMaxExp: 400,
                vipIcon: "http://static.sandboxol.com/sandbox/icon/props/VIP/huizhang_V1.png",
                clothVoucherCount: null,
                actualCountry: "PK",
                stopToTime: null
                // Add other user information fields as needed
            };

            res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
        });
    } catch (err) {
        console.error('Error retrieving user info:', err);
        res.status(500).json({ message: 'Error retrieving user info.' });
    }
});

app.get('/user/api/v1/chat/migrate/data', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": null,
  "data": {
    "oldRongcloudKey": null,
    "newRongcloudKey": null,
    "migrate": 0,
    "idDelta": 0
  },
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/event-blacklist-config', (req, res) => {
    // Sample game data for g1014
    
    // Sending the response
    res.json(blacklistJson);
});

app.get('/config/files/blockmods-config', (req, res) => {
    // Sample game data for g1014

    // Sending the response
    res.json(blockmodsJson);
});

app.put('/user/api/v1/user/info', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            let user = await User.findOne({ userId });

            // If user not found, return error
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            const { details, birthday, picUrl } = req.body;

            // Check if details or birthday are provided
            if (!details && !birthday  && !picUrl) {
                return res.status(400).json({ message: 'Either details or birthday picUrl is required.' });
            }

            // Update details if provided
            if (details !== undefined) {
                user.introduction = details;
            }

            // Update birthday if provided
            if (birthday !== undefined) {
                user.birthday = birthday;
            }

            if (picUrl !== undefined) {
                user.picUrl = picUrl;
            }

            // Save the updated user
            await user.save();

            // Return success response with updated details and birthday
            res.status(200).json({ code: 1, message: 'SUCCESS', data: { nickName: user.nickname, picUrl: user.picUrl, sex: user.sex, details: user.introduction, birthday: user.birthday } });
        });
    } catch (err) {
        console.error('Error updating user info:', err);
        res.status(500).json({ message: 'Error updating user info.' });
    }
});

app.get('/friend/api/v1/friends/info/:nickname', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { nickname } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            let query = {}; // Default empty query
            if (nickname) {
                // If nickname parameter is provided, search for users with nicknames starting with the provided word
                query = { nickname: { $regex: '^' + nickname, $options: 'i' } };
            }

            // Query the database based on the constructed query
            const users = await User.find(query);

            // Prepare the response
            const responseData = users.map(user => ({
                userId: user.userId,
                nickName: user.nickname,
                picUrl: user.picUrl || '', // Assuming picUrl is optional in the user model
                picType: 0,
                decorationPicUrl: null,
                alias: null,
                status: 30,
                gameId: null,
                partyInfo: null,
                vip: user.vip  || 0,
                expireDate: null,
                sex: 2,
                details: user.introduction,
                clanId: 0,
                clanName: null,
                role: 0,
                userGameDataResponse: null,
                age: 0,
                country: null,
                language: "en",
                logoutTime: 0,
                colorfulNickName: user.colorfulname,
                avatarFrame: null,
                userLevel: 1,
                levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
                birthday: "",
                region: null,
                regionCode: 0,
                regionCreateTime: 1624972168000,
                gameName: null,
                vipLv: 0,
                vipExp: 0,
                vipMaxExp: 0,
                vipIcon: null,
                showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
                memberType: null,
                memberName: null,
                ownerType: null,
                ownerName: null,
                recruitInfo: null,
                familyTagList: null,
                onlyTag: null,
                family: false,
                suitExhibitionList: null,
                personalityItems: {
                    nameplate: "vip_nameplate_0.png"
                },
                friend: false
            }));

            // Return the search results
            res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo: 0,
                    pageSize: 10,
                    totalPage: 1,
                    totalSize: responseData.length,
                    data: responseData,
                    other: null
                }
            });
        });
    } catch (err) {
        console.error('Error searching for friends:', err);
        res.status(500).json({ message: 'Error searching for friends.' });
    }
});

app.get('/friend/api/v1/friends/info/id/:userId', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { userId: searchUserId } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Query the database for the user by userId
            const user = await User.findOne({ userId: searchUserId });

            // Check if the user exists
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }
const clan = await ClanDB.findOne({ clanId: user.clanId });
            // Prepare the response
            const responseData = {
                userId: user.userId,
                nickName: user.nickname,
                picUrl: user.picUrl || '', // Assuming picUrl is optional in the user model
                picType: 0,
                decorationPicUrl: null,
                alias: null,
                status: 30,
                gameId: null,
                partyInfo: null,
                vip: user.vip || 0,
                expireDate: null,
                sex: 2,
                details: user.introduction,
                clanId: clan.clanId  || 0,
            clanName: clan.clanName  || null,
            role: clan.clanRole  || 0,
                userGameDataResponse: null,
                lmaololq: null,
                age: 0,
                country: null,
                language: "en",
                logoutTime: 0,
                colorfulNickName: user.colorful,
                avatarFrame: null,
                userLevel: 1,
                levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
                birthday: "",
                region: null,
                regionCode: 0,
                regionCreateTime: 1624972168000,
                gameName: null,
                vipLv: 0,
                vipExp: 0,
                vipMaxExp: 0,
                vipIcon: null,
                showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
                memberType: null,
                memberName: null,
                ownerType: null,
                ownerName: null,
                recruitInfo: null,
                familyTagList: null,
                onlyTag: null,
                family: false,
                suitExhibitionList: null,
                personalityItems: {
                    nameplate: "vip_nameplate_0.png"
                },
                friend: false
            };

            // Return the user data
            res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: {
                    pageNo: 0,
                    pageSize: 10,
                    totalPage: 1,
                    totalSize: 0,
                    data: responseData,
                    other: null
                }
            });
        });
    } catch (err) {
        console.error('Error searching for user:', err);
        res.status(500).json({ message: 'Error searching for user.' });
    }
});

app.get('/clan/api/v1/clan/tribe/donation', async (req, res) => {
    const userId = req.headers['userid'];

    // Check if userId and clanId are provided
    if (!userId || !clanId) {
        return res.status(400).json({ message: 'UserId and clanId are required.' });
    }

    try {
        // Fetch user's VIP level from userdb
        const user = await User.findOne({ userId });
        const userVipLevel = user.vip || 0;

        // Fetch clan's donation information from clanDB
        const clan = await ClanDB.findOne({ clanId: user.clanId });
        if (!clan) {
            return res.status(404).json({ message: 'Clan not found with the provided clanId.' });
        }

        // Calculate current and max gold and diamond based on VIP level
        let maxGold = 580;
        let maxDiamond = 7;

        if (userVipLevel === 1) {
            maxGold = 1280;
            maxDiamond = 10;
        } else if (userVipLevel === 2) {
            maxGold = 1680;
            maxDiamond = 16;
        } else if (userVipLevel === 3) {
            maxGold = 2680;
            maxDiamond = 26;
        }

        // Fetch user's donation information from userdb
        // Here you would have logic to fetch the current gold and diamond donated by the user
        const currentGold = 0; // Replace 0 with the actual value from userdb
        const currentDiamond = 0; // Replace 0 with the actual value from userdb

        // Prepare the response data
        const responseData = {
            clanId: clan.clanId,
            level: clan.level,
            currentExperience: clan.experience,
            maxExperience: clan.maxExperience,
            currentTask: clan.currentTask,
            maxTask: clan.maxTask,
            currentGold,
            maxGold,
            currentDiamond,
            maxDiamond
        };

        // Return the donation information as the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
    } catch (err) {
        console.error('Error retrieving donation information:', err);
        res.status(500).json({ message: 'Error retrieving donation information.' });
    }
});

app.put('/clan/api/v1/clan/free/verification', async (req, res) => {
    const userId = req.headers['userid'];
    const { freeVerify } = req.query;

    // Check if userId and freeVerify are provided
    if (!userId || freeVerify === undefined) {
        return res.status(400).json({ message: 'UserId and freeVerify are required.' });
    }

    try {
        // Fetch user's clanId from userdb
        const user = await User.findOne({ userId });
        if (!user) {
            return res.status(404).json({ message: 'User not found with the provided userId.' });
        }

        // Fetch clan from clanDB based on user's clanId
        const clan = await ClanDB.findOne({ clanId: user.clanId });
        if (!clan) {
            return res.status(404).json({ message: 'Clan not found with the provided clanId.' });
        }

        // Update clan's freeVerify status
        clan.freeVerify = freeVerify;
        await clan.save();

        // Prepare the response data
        const responseData = {
            clanId: clan.clanId,
            name: clan.name,
            headPic: clan.headPic,
            tags: clan.tags,
            details: clan.details,
            experience: clan.experience,
            level: clan.level,
            role: clan.role,
            freeverify: clan.freeverify,
            currentCount: clan.currentCount,
            maxCount: clan.maxCount,
            maxElderCount: clan.maxElderCount,
            region: clan.region
        };

        // Return the updated clan information as the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
    } catch (err) {
        console.error('Error updating free verification status:', err);
        res.status(500).json({ message: 'Error updating free verification status.' });
    }
});

app.post('/clan/api/v1/clan/tribe/bulletin', async (req, res) => {
    const userId = req.headers['userid'];
    const { content } = req.body;

    // Check if userId and content are provided
    if (!userId || content === undefined) {
        return res.status(400).json({ message: 'UserId and content are required.' });
    }

    try {
        // Fetch user's clanId from userdb
        const user = await User.findOne({ userId });
        if (!user) {
            return res.status(404).json({ message: 'User not found with the provided userId.' });
        }

        // Fetch clan from clanDB based on user's clanId
        const clan = await ClanDB.findOne({ clanId: user.clanId });
        if (!clan) {
            return res.status(404).json({ message: 'Clan not found with the provided clanId.' });
        }

        // Update clan's bulletin content
        clan.lmaololq = content;
        await clan.save();

        // Prepare the response data
        const responseData = {
            content: clan.lmaololq,
            updateTime: Date.now() // Current timestamp
        };

        // Return the updated bulletin information as the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
    } catch (err) {
        console.error('Error updating bulletin:', err);
        res.status(500).json({ message: 'Error updating bulletin.' });
    }
});

app.put('/user/api/v1/user/info', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            const { birthday } = req.body;

            // Check if introduction is provided
            if (!birthday) {
                return res.status(400).json({ message: 'Introduction is required.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, return error
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Check if the provided details are the same as the user's current details
            if (birthday === user.birthday) {
                // If they are the same, return success response
                return res.status(200).json({ code: 1, message: 'SUCCESS', data: { birthday: user.birthday } });
            }

            // Update the introduction
            user.birthday = birthday;

            // Save the updated user
            await user.save();

            // Return success response
            res.status(200).json({ code: 1, message: 'SUCCESS', data: { introduction: user.birthday } });
        });
    } catch (err) {
        console.error('Error updating user introduction:', err);
        res.status(500).json({ message: 'Error updating user introduction.' });
    }
});





app.get('/pay/api/v1/first/punch/reward', (req, res) => {
    const responseData = {
"code": 1,
  "message": null,
  "data": {
    "status": 0,
    "rewardList": [
      {
        "picUrl": "http://static.sandboxol.com/sandbox/images/banner/custom_glasses.3-.png",
        "name": "Rich Glasses"
      },
      {
        "picUrl": "http://static.sandboxol.com/sandbox/images/banner/clothes_tops.34.png",
        "name": "Rich T_shirt"
      },
      {
        "picUrl": "http://static.sandboxol.com/sandbox/images/banner/clothes_pants.34.png",
        "name": "Rich Shorts"
      },
      {
        "picUrl": "http://static.sandboxol.com/sandbox/images/banner/cube.png",
        "name": "cube 100"
      },
      {
        "picUrl": "http://static.sandboxol.com/sandbox/images/banner/gold.png",
        "name": "golds 6999"
      }
    ]
}
    };

    // Sending the response
    res.json(responseData);
});

app.put('/user/api/v1/users/:userId/daily/tasks/ads', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Assuming you have a function to get the user from the database based on userId
                  let user = await User.findOne({ userId });

            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Update user's balance
            user.diamonds += 2; // Assuming diamonds reward quantity is always 2

            // Save the updated user
            await user.save();

            // Return success response with updated balances
            res.status(200).json({ code: 1, message: 'SUCCESS', data: {
                userId: user.userId,
                diamonds: user.diamonds,
                golds: user.gold,
                currency: 1,
                rewardQuantity: 2
            } });
        });
    } catch (err) {
        console.error('Error giving rewards:', err);
        res.status(500).json({ message: 'Error giving rewards.' });
    }
});

app.get('/clan/api/v1/clan/tribe/base', async (req, res) => {
    // Extracting userId and accessToken from headers
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userId and accessToken are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'userId and accessToken headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if decoded userId matches the one in headers
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, return error
            if (!user) {
                return res.status(404).json({ code: 1, message: 'SUCCESS', data: null, other: null });
            }
            // Fetch clan information based on user's clanId
            let clan = await ClanDB.findOne({ clanId: user.clanId });

            // If clan not found, return error
            if (!clan) {
                return res.status(404).json({ code: 7006, message: 'not join tribe', data: null, other: null });
            }

            // Prepare the response with clan information
            const responseData = {
                clanId: clan.clanId,
                name: clan.name,
                headPic: clan.headPic,
                tags: clan.tags,
                details: clan.details,
                experience: clan.experience,
                level: clan.level,
                role: clan.role,
                freeverify: clan.freeverify,
                currentCount: clan.currentCount,
                maxCount: clan.maxCount,
                maxElderCount: clan.maxElderCount,
                region: clan.region
            };

            // Sending the success response
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData, other: null });
        });
    } catch (err) {
        console.error('Error retrieving clan info:', err);
        res.status(500).json({ message: 'Error retrieving clan info.' });
    }
});

app.get('/clan/api/v1/clan/tribe/id', (req, res) => {
    // Sample game data for g1014
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, create a new user

            // Customize the response with required user information

            res.status(200).json({ 
                code: 1, 
                message: 'SUCCESS', 
                data: user.clanId,
                other: null 
            });
        });
    } catch (err) {
        console.error('Error retrieving user info:', err);
        res.status(500).json({ message: 'Error retrieving user info.' });
    }
});

// Assuming you are using Express.js
app.get('/friend/api/v1/friends/recommendation', async (req, res) => {
    try {
        // Fetch random users from the database
        const users = await User.aggregate([{ $sample: { size: 10 } }]);

        // Map the fetched users to the desired response format
        const responseData = users.map(user => ({
            userId: user.userId,
            nickName: user.nickname,
            headPic: user.picUrl || '',
            picType: 0,
            decorationPicUrl: null,
            alias: null,
            status: 30,
            gameId: null,
            partyInfo: null,
            vip: user.vip || 0,
            expireDate: null,
            sex: user.sex || '2',
            details: user.introduction,
            clanId: 0,
            clanName: null,
            role: 0,
            userGameDataResponse: null,
            age: 0,
            country: null,
            language: "en",
            logoutTime: 0,
            colorfulNickName: user.colorful,
            avatarFrame: null,
            userLevel: 1,
            levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
            birthday: "",
            region: null,
            regionCode: 0,
            regionCreateTime: 1624972168000,
            gameName: null,
            vipLv: 0,
            vipExp: 0,
            vipMaxExp: 0,
            vipIcon: null,
            showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
            memberType: null,
            memberName: null,
            ownerType: null,
            ownerName: null,
            recruitInfo: null,
            familyTagList: null,
            onlyTag: null,
            family: false,
            suitExhibitionList: null,
            personalityItems: {
                nameplate: "vip_nameplate_0.png"
            },
            friend: false
        }));

        // Return the list of recommended users as the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
    } catch (err) {
        console.error('Error recommending friends:', err);
        res.status(500).json({ message: 'Error recommending friends.' });
    }
});

app.get('/friend/api/v1/friends/:userId', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { userId: searchUserId } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Query the database for the user by userId
            const user = await User.findOne({ userId: searchUserId });

            // Check if the user exists
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }
const clan = await ClanDB.findOne({ clanId: user.clanId });
            // Prepare the response
            const responseData = {
                userId: user.userId,
                nickName: user.nickname,
                picUrl: user.picUrl || '', // Assuming picUrl is optional in the user model
                picType: 0,
                decorationPicUrl: null,
                alias: null,
                status: 30,
                gameId: null,
                partyInfo: null,
                vip: user.vip || 0,
                expireDate: null,
                sex: user.sex || '2',
                details: user.introduction,
                clanId: clan.clanId  || 0,
            clanName: clan.clanName  || null,
            role: clan.clanRole  || 0,
                userGameDataResponse: null,
                age: 0,
                country: null,
                language: "en",
                logoutTime: 0,
                colorfulNickName: user.colorful,
                avatarFrame: null,
                userLevel: 1,
                levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
                birthday: "",
                region: null,
                regionCode: 0,
                regionCreateTime: 1624972168000,
                gameName: null,
                vipLv: 0,
                vipExp: 0,
                vipMaxExp: 0,
                vipIcon: null,
                showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
                memberType: null,
                memberName: null,
                ownerType: null,
                ownerName: null,
                recruitInfo: null,
                familyTagList: null,
                onlyTag: null,
                family: false,
                suitExhibitionList: null,
                personalityItems: {
                    nameplate: "vip_nameplate_0.png"
                },
                friend: false
            };

            // Return the user data
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (err) {
        console.error('Error searching for user:', err);
        res.status(500).json({ message: 'Error searching for user.' });
    }
});



app.get('/decoration/api/v1/decorations/:userId/using', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { userId: searchUserId } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Query the database for the user by userId
            const user = await User.findOne({ userId: searchUserId });

            // Check if the user exists
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Query the EquippedAvatar collection for avatars associated with the user
            const avatars = await EquippedAvatar.find({ userId: searchUserId });

            // Parse the response data
            const responseData = avatars.map(avatar => ({
                id: avatar.avatarId,
                typeId: avatar.avatarTypeId,
                camera: avatar.avatarCamera,
                name: avatar.avatarName,
                iconUrl: avatar.avatarIconUrl,
                resourceId: avatar.avatarResourceId,
                details: avatar.avatarDetails,
                price: avatar.avatarPrice,
                currency: avatar.avatarCurrency
            }));

            // return the avatars being used by the user
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (error) {
        console.error('Error fetching avatars:', error);
        res.status(500).json({ message: 'Error fetching avatars.' });
    }
});
// Assuming you have already initialized your express app and mongoose connection

// Define the mail schema
// Define the Mail model


// API endpoint to get all mails
app.get('/mailbox/api/v1/mail', async (req, res) => {
    // Extract userId and accessToken from headers
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userId and accessToken are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'UserId and Access-Token headers are required.' });
    }

    try {
        // Verify the access token (You need to implement this part)
        // Example: jwt.verify(accessToken, JWT_SECRET, (error, decoded) => {...});

        // Fetch mails from the database that match the userId
        const userMails = await Mail.find({ userId: userId });

        // Construct the response data
        const responseData = userMails.map(mail => ({
            id: mail.id,
            title: mail.title,
            content: mail.description,
            sendDate: mail.sendDate.getTime(), // Convert Date object to timestamp
            status: mail.status,
            type: mail.type,
            attachment: mail.attachment,
            extra: mail.extra
        }));

        // Construct the success response
        const successResponse = {
            code: 1,
            message: 'SUCCESS',
            data: responseData,
            other: null
        };

        // Return success response with the filtered mail data
        res.status(200).json(successResponse);
    } catch (err) {
        console.error('Error fetching mails:', err);
        res.status(500).json({ message: 'Error fetching mails.' });
    }
});




// Define the schema for the mail data

// POST endpoint to send mail
app.post('/mailbox/api/v1/sendmail', async (req, res) => {
       

    try {
        const { title, description, userId } = req.body;

        // Validate if title, description, and userId are provided
        if (!title || !description || !userId) {
            return res.status(400).json({ message: 'Title, description, and userId are required.' });
        }

        let recipients = [];

        // If userId is an array, assign it to recipients
        if (Array.isArray(userId)) {
            recipients = userId;
        } else {
            // If userId is a single value, add it to recipients array
            recipients.push(userId);
        }

        // Array to hold the mail documents to be saved
        const mails = [];

        // Iterate through each recipient and create a mail document for each
        for (const recipientId of recipients) {
            // Generate a unique ID for the mail
            const mailId = Math.floor(Math.random() * 1000000).toString();

            // Create the mail object
            const mail = new Mail({
                id: mailId,
                title: title,
                description: description,
                userId: recipientId
            });

            // Save the mail to the database
            await mail.save();

            // Push the mail object to the mails array
            mails.push(mail);
        }

        // Construct the success response
        const successResponse = {
            code: 1,
            message: 'SUCCESS',
            data: mails.map(mail => ({
                id: mail.id,
                title: title,
                description: description,
                status: 2,
                type: 0,
                attachment: null,
                extra: null,
                sendDate: mail.sendDate
            }))
        };

        // Return success response with the mail data
        res.status(200).json(successResponse);
    } catch (err) {
        console.error('Error sending mail:', err);
        res.status(500).json({ message: 'Error sending mail.' });
    }
});


app.get('/mailbox/api/v1/mail/new', (req, res) => {
    const responseData = {
 "code": 1,
  "message": "SUCCESS",
  "data": false,
  "other": null
    };

    // Sending the response
    res.json(responseData);
});

app.get('/pay/api/v1/pay/products/vip', (req, res) => {
    // Sample game data for g1014
    const gameData = {
"code": 1,
  "message": "SUCCESS",
  "data": {
    "vip": 0,
    "products": {
      "1": [
        {
          "id": 13,
          "productId": "and.vip.1.1",
          "price": 0.99,
          "localPrice": "PKR 280.00",
          "gift": 0,
          "name": "vip月卡",
          "desc": "vip月卡",
          "level": 1,
          "month": 1,
          "type": "vip",
          "diamonds": 66,
          "garenaProductId": null,
          "gopId": null
        },
        {
          "id": 14,
          "productId": "and.vip.1.12",
          "price": 10.99,
          "localPrice": "PKR 3350.00",
          "gift": 0,
          "name": "vip年卡",
          "desc": "vip年卡",
          "level": 1,
          "month": 12,
          "type": "vip",
          "diamonds": 0,
          "garenaProductId": null,
          "gopId": null
        }
      ],
      "2": [
        {
          "id": 15,
          "productId": "and.vip.2.1",
          "price": 4.99,
          "localPrice": "PKR 1400.00",
          "gift": 0,
          "name": "vip+月卡",
          "desc": "vip+月卡",
          "level": 2,
          "month": 1,
          "type": "vip",
          "diamonds": 360,
          "garenaProductId": null,
          "gopId": null
        },
        {
          "id": 16,
          "productId": "and.vip.2.12",
          "price": 49.99,
          "localPrice": "PKR 14100.00",
          "gift": 0,
          "name": "vip+年卡",
          "desc": "vip+年卡",
          "level": 2,
          "month": 12,
          "type": "vip",
          "diamonds": 0,
          "garenaProductId": null,
          "gopId": null
        }
      ],
      "3": [
        {
          "id": 17,
          "productId": "and.vip.3.1",
          "price": 9.99,
          "localPrice": "PKR 2800.00",
          "gift": 0,
          "name": "mvp月卡",
          "desc": "mvp月卡",
          "level": 3,
          "month": 1,
          "type": "vip",
          "diamonds": 800,
          "garenaProductId": null,
          "gopId": null
        },
        {
          "id": 18,
          "productId": "and.vip.3.12",
          "price": 89.99,
          "localPrice": "PKR 28200.00",
          "gift": 0,
          "name": "mvp年卡",
          "desc": "mvp月卡年卡",
          "level": 3,
          "month": 12,
          "type": "vip",
          "diamonds": 0,
          "garenaProductId": null,
          "gopId": null
        }
      ]
    },
    "expireDate": null
  }
    };

    // Sending the response
    res.json(gameData);
});

app.get('/config/files/payConfig', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "OK",
  "data": {
    "and.gcubes.1": 0.99,
    "and.gcubes.5": 4.99,
    "and.gcubes.10": 9.99,
    "and.gcubes.25": 24.99,
    "and.gcubes.50": 49.99,
    "and.gcubes.100": 99.99,
    "ios.gcubes.1": 0.99,
    "ios.gcubes.5": 4.99,
    "ios.gcubes.10": 9.99,
    "ios.gcubes.25": 24.99,
    "ios.gcubes.50": 49.99,
    "ios.gcubes.100": 99.99,
    "and.vipsub.2.1": 4.99,
    "and.vipsub.3.1": 9.99,
    "ios.vipsub.2.1": 4.99,
    "ios.vipsub.3.1": 9.99,
    "ios.vipsub.4.1": 24.99,
    "and.vipsub.4.1": 24.99
  },
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/pay/api/v1/wealth/user', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch user information from the database based on userId
            let user = await User.findOne({ userId });

            // If user not found, return appropriate response
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Customize the response with required user information
            const userInfo = {
                userId: user.userId,
                currency: user.currency || 0, // Default to 0 if currency is not set
                diamonds: user.diamonds || 0, // Default to 0 if diamonds is not set
                golds: user.gold || 0, // Default to 0 if gold is not set
                gDiamonds: user.gDiamonds || 0, // Default to 0 if gDiamonds is not set
                gDiamondsProfit: 0,
                money: 0.0,
                ngDiamonds: 0.0,
                sameUser: false,
                firstPunch: false
            };

            res.status(200).json({ code: 1, message: 'SUCCESS', data: userInfo });
        });
    } catch (err) {
        console.error('Error retrieving user info:', err);
        res.status(500).json({ message: 'Error retrieving user info.' });
    }
});

app.get('/shop/api/v1/shop/decorations/1', async (req, res) => {
  const userId = req.headers['userid'];
  const accessToken = req.headers['access-token'];

  // Check if userId and accessToken are provided
  if (!userId || !accessToken) {
    return res.status(400).json({ message: 'UserId and Access-Token headers are required.' });
  }

  try {
    // Verify the access token
    jwt.verify(accessToken, JWT_SECRET, async (err, decoded) => {
      if (err) {
        console.error('Access token verification failed:', err);
        return res.status(401).json({ message: 'Invalid Access-Token.' });
      }

      // Check if the decoded user ID matches the provided user ID
      if (decoded.userId !== userId) {
        return res.status(403).json({ message: 'Access-Token does not match userId.' });
      }

      // Fetch all avatars from the database
      let avatars = await Shop.find();

      // Filter out avatars without a 'name' property
      avatars = avatars.filter(avatar => avatar.name);

      // Sort the avatars based on camera and the presence of the name "shoes"
      avatars.sort((a, b) => {
        // Sort by camera: top first, then bottom
        if (a.camera === 'top' && b.camera === 'bottom') return -1;
        if (a.camera === 'bottom' && b.camera === 'top') return 1;

        // If both are of the same camera type or both are different, sort by name
        if (a.name.includes('shoes') && !b.name.includes('shoes')) return 1;
        if (!a.name.includes('shoes') && b.name.includes('shoes')) return -1;

        // If neither avatar has "shoes" in their name or they have the same camera type, keep the original order
        return 0;
      });

      // Map the fetched and sorted avatars to the desired response format
      const responseData = avatars.map(avatar => ({
        id: avatar.id,
        typeId: avatar.typeId,
        camera: avatar.camera,
        name: avatar.name,
        iconUrl: avatar.iconUrl,
        status: 0,
        sex: 0,
        tag: [],
        resourceId: avatar.resourceId,
        details: avatar.details,
        price: avatar.price,
        currency: avatar.currency,
        database: avatar.database,
        expire: 0,
        type: 0,
        clanLevel: 0,
        vip: 0,
        occupyPosition: [12]
      }));

      res.json({ code: 1, message: 'SUCCESS', data: responseData });
    });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

// Method to get friends status
app.get('/friend/api/v1/statusmodify', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if Access-Token and userId headers are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userid headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Find friends for the user
            const friendList = await Friend.find({ friendFor: userId });

            // Construct data array with friend status details
            const status = await Promise.all(friendList.map(async (friend) => {
                // Find friend details from the user database
                const friendUser = await User.findOne({ userId: friend.userId });

                // Extract necessary details from the friend user
                const friendStatus = {
                    userId: friendUser.userId,
                    status: friend.status || 0, // Replace with actual status from friend database
                    gameId: friendUser.gameId || null,
                    gameMode: friendUser.gameMode || null,
                    partyInfo: friendUser.partyInfo || null,
                    packageName: friendUser.packageName || null,
                    gamingInfo: friendUser.gamingInfo || null,
                    logoutTime: friendUser.logoutTime || null,
                    colorfulNickName: friendUser.colorfulNickName || null,
                    avatarFrame: friendUser.avatarFrame || null,
                    nickName: friendUser.nickname || '',
                    updateTime: friendUser.updateTime || 0,
                    os: friendUser.os || null,
                    personalityItems: friendUser.personalityItems || null,
                    gameName: friendUser.gameName || null
                };

                return friendStatus;
            }));

            // Construct response
            const response = {
                maxFriendCount: 500, // Assuming max friend count is fixed
                curFriendCount: status.length,
                status: status,
                currentTime: Date.now() // Current timestamp
            };

            res.status(200).json({ code: 1, message: 'SUCCESS', data: response, other: null });
        });
    } catch (error) {
        console.error('Error fetching friends status:', error);
        res.status(500).json({ message: 'Error fetching friends status.' });
    }
});

app.get('/clan/api/v1/clan/tribe/recommendation', async (req, res) => {
    try {
        // Fetch random clans from the database
        const clans = await ClanDB.aggregate([{ $sample: { size: 10 } }]);

        // Map the fetched clans to the desired response format
        const responseData = clans.map(clan => ({
            chiefId: clan.chiefId,
            chiefNickName: clan.chiefName,
            headPic: clan.headPic || '',
            detail: clan.details,
            freeVerify: clan.freeVerify,
            isFirst: false,
            level: clan.level,
            clanId: clan.clanId,
            currentCount: clan.currentCount,
            maxCount: clan.maxCount,
            name: clan.name || null
        }));

        // Return the list of recommended clans as the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
    } catch (err) {
        console.error('Error recommending clans:', err);
        res.status(500).json({ message: 'Error recommending clans.' });
    }
});


app.get('/friend/api/v1/friends/:userId', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];
    const { userId: searchUserId } = req.params;

    // Check if accessToken and userId are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        const decoded = jwt.verify(accessToken, JWT_SECRET);

        // Check if the decoded user ID matches the provided user ID
        if (decoded.userId !== userId) {
            return res.status(403).json({ message: 'Access-Token does not match userId.' });
        }

        // Query the database for the user by userId
        const user = await User.findOne({ userId: searchUserId });

        // Check if the user exists
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

const clan = await ClanDB.findOne({ clanId: user.clanId });

        // Prepare the response
        const responseData = {
            userId: user.userId || '',
            nickName: user.nickname || '',
            picUrl: user.picUrl || '', // Assuming picUrl is optional in the user model
            picType: 0,
            decorationPicUrl: null,
            alias: null,
            status: 30,
            gameId: null,
            partyInfo: null,
            vip: user.vip || 0,
            expireDate: null,
            sex: 2,
            details: user.introduction || '',
            clanId: clan.clanId  || 0,
            clanName: clan.clanName  || null,
            role: clan.clanRole  || 0,
            userGameDataResponse: null,
            age: 0,
            country: null,
            language: "en",
            logoutTime: 0,
            colorfulNickName: user.colorful || null,
            avatarFrame: null,
            userLevel: 1,
            levelPic: "http://static.sandboxol.com/sandbox/accountLevel/icon/1.png",
            birthday: "",
            region: null,
            regionCode: 0,
            regionCreateTime: 1624972168000,
            gameName: null,
            vipLv: 0,
            vipExp: 0,
            vipMaxExp: 0,
            vipIcon: null,
            showUrl: "http://staticgs.sandboxol.com/sandbox/avatar/1689758841893158.jpg",
            memberType: null,
            memberName: null,
            ownerType: null,
            ownerName: null,
            recruitInfo: null,
            familyTagList: null,
            onlyTag: null,
            family: false,
            suitExhibitionList: null,
            personalityItems: {
                nameplate: "vip_nameplate_0.png"
            },
            friend: false
        };

        // Return the user data
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
    } catch (err) {
        console.error('Error searching for user:', err);
        res.status(500).json({ message: 'Error searching for user.' });
    }
});

app.get('/game/api/v1/games/recommendation/type', async (req, res) => {
    try {
        // Query the game database to find recommended games
        const recommendedGames = await Game.find({}); // Adjust the query based on your database schema

        // Prepare the response data
        const responseData = recommendedGames.map(game => ({
            gameId: game.gameId,
            gameTitle: game.gameTitle,
            gameCoverPic: game.gameCoverPic,
            visitorEnter: game.visitorEnter,
            praiseNumber: game.praiseNumber
        }));

        // Return the search results with fixed values for pageNo, pageSize, totalPage, and totalSize
        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo: 0, // Fixed value
                pageSize: 1, // Fixed value
                totalPage: 7, // Fixed value
                totalSize: 1, // Fixed value
                data: responseData,
                other: null
            }
        });
    } catch (error) {
        console.error('Error searching for recommended games:', error);
        res.status(500).json({ message: 'Error searching for recommended games.' });
    }
});

app.get('/game/api/v2/games/recommendation/type', async (req, res) => {
    try {
        // Query the game database to find recommended games
        const recommendedGames = await Game.find({}); // Adjust the query based on your database schema

        // Prepare the response data
        const responseData = recommendedGames.map(game => ({
            gameId: game.gameId,
            gameTitle: game.gameTitle,
            gameCoverPic: game.gameCoverPic,
            visitorEnter: game.visitorEnter,
            praiseNumber: game.praiseNumber
        }));

        // Return the search results with fixed values for pageNo, pageSize, totalPage, and totalSize
        res.status(200).json({
            code: 1,
            message: 'SUCCESS',
            data: {
                pageNo: 0, // Fixed value
                pageSize: 0, // Fixed value
                totalPage: 168, // Fixed value
                totalSize: 0, // Fixed value
                data: responseData,
                other: null
            }
        });
    } catch (error) {
        console.error('Error searching for recommended games:', error);
        res.status(500).json({ message: 'Error searching for recommended games.' });
    }
});

app.get('/api/v1/games/playlist/recently', (req, res) => {
    // Sample game data for g1014
    const gameData = {
"code": 1,
  "message": "SUCCESS",
  "data": [],
  "other": null
    };

    // Sending the response
    res.json(gameData);
});



app.get('/shop/api/%7Bversion%7D/shop/game/props', (req, res) => {
    // Sample game data for g1014
    const gameData = {
"code": 1,
  "message": "SUCCESS",
  "data": [
    {
      "id": 49,
      "resourceId": "game.props.22",
      "iconUrl": "http://static.sandboxol.com/sandbox/games/images/game.props.22.undefined.1545191844476.传送珍珠",
      "validate": 3,
      "price": 50,
      "status": 0,
      "currency": 1,
      "expireDate": null,
      "name": "[3 day] Flash Pearl",
      "details": "Obtain 3 flash pearls. Throw it out to be flashed to the landing place"
    },
    {
      "id": 52,
      "resourceId": "game.props.19",
      "iconUrl": "http://static.sandboxol.com/sandbox/games/images/undefined.1(1).1545192864800.png",
      "validate": 7,
      "price": 100,
      "status": 0,
      "currency": 1,
      "expireDate": null,
      "name": "[7 days]Sliver bar goodie bag",
      "details": "Get 20 sliver bar at the start of every game"
    },
    {
      "id": 53,
      "resourceId": "game.props.20",
      "iconUrl": "http://static.sandboxol.com/sandbox/games/images/undefined.2(1).1545192917683.png",
      "validate": 7,
      "price": 150,
      "status": 0,
      "currency": 1,
      "expireDate": null,
      "name": "[7 days]Gold bar goodie bag",
      "details": "Get 15 gold bar at the start of every game"
    }
  ],
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.get('/shop/api/v1/shop/decorations/3', (req, res) => {
    // Sample game data for g1014
    const gameData = {
  "code": 1,
  "message": "SUCCESS",
  "data": [
    {
      "id": 141,
      "typeId": 14,
      "camera": "top",
      "name": null,
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_bag.6.custom_bag.1516873715037.6",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.8",
      "details": null,
      "expire": 0,
      "price": 120,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 8,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 120,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 139,
      "typeId": 14,
      "camera": "top",
      "name": "Captain America\u0027s Shield",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_bag.5.custom_bag.1516870760867.5",
      "sex": 1,
      "tag": [],
      "resourceId": "custom_wing.7",
      "details": "Captain America\u0027s Shield",
      "expire": 0,
      "price": 220,
      "discountPrice": null,
      "clothVoucherPrice": 100,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 7,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 220,
          "clothVoucherPrice": 100
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 2,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 140,
      "typeId": 14,
      "camera": "top",
      "name": "black sport backpack",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_bag.4.custom_bag.1516870663912.4",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.6",
      "details": "black sport backpack",
      "expire": 0,
      "price": 180,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 1,
      "orderField": 6,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 180,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 138,
      "typeId": 14,
      "camera": "top",
      "name": "blue sports bag",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_bag.3.custom_bag.1516870620040.3",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.5",
      "details": "blue sports bag",
      "expire": 0,
      "price": 200,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 5,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 200,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 137,
      "typeId": 14,
      "camera": "top",
      "name": null,
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_bag.2.custom_bag.1516870566646.2",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.4",
      "details": null,
      "expire": 0,
      "price": 150,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 4,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 150,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 92,
      "typeId": 14,
      "camera": "top",
      "name": "Yellow-green bag",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_wing.3.custom_wing.1514521061552.3",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.3",
      "details": "Yellow-green bag",
      "expire": 0,
      "price": 12000,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 2,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 3,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 12000,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 136,
      "typeId": 11,
      "camera": "head",
      "name": "Silver headphones",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_hat.2.custom_hat.1516871067145.2",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_hat.2",
      "details": "Silver headphones",
      "expire": 0,
      "price": 160,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 2,
      "isRecommend": 1,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 160,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        11
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "fashi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 2,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 90,
      "typeId": 13,
      "camera": "head",
      "name": "Red scarf",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_scarf.2.custom_scarf.1514520503000.2",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_scarf.2",
      "details": "Red scarf",
      "expire": 0,
      "price": 120,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 2,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 120,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        13
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "jianshi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 89,
      "typeId": 14,
      "camera": "top",
      "name": "Blue cloak",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_wing.2.custom_wing.1514520882097.2",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.2",
      "details": "Blue cloak",
      "expire": 0,
      "price": 999,
      "discountPrice": null,
      "clothVoucherPrice": 100,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 2,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 999,
          "clothVoucherPrice": 100
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 2,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 39,
      "typeId": 12,
      "camera": "head",
      "name": "Square black frame glasses",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_glasses.2.custom_glasses.1514549341971.2",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_glasses.2",
      "details": "Square black frame glasses",
      "expire": 0,
      "price": 150,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 2,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 150,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        12
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "mianshi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 2,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 91,
      "typeId": 13,
      "camera": "head",
      "name": "Green scarf",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_scarf.1.custom_scarf.1514520393442.1",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_scarf.1",
      "details": "Green scarf",
      "expire": 0,
      "price": 120,
      "discountPrice": null,
      "clothVoucherPrice": 30,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 1,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 120,
          "clothVoucherPrice": 30
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        13
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "jianshi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 1,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    },
    {
      "id": 304,
      "typeId": 14,
      "camera": "top",
      "name": "Count Pumpkin Cape",
      "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_wing.14.custom_wing.1571738201053.14",
      "sex": 0,
      "tag": [],
      "resourceId": "custom_wing.14",
      "details": "Count Pumpkin Cape",
      "expire": 0,
      "price": 999,
      "discountPrice": null,
      "clothVoucherPrice": 100,
      "discountClothVoucherPrice": null,
      "currency": 1,
      "quantity": 0,
      "isNew": 1,
      "hasPurchase": 0,
      "orderField": 2,
      "isRecommend": 0,
      "suitId": null,
      "suitPrice": null,
      "suitClothVoucherPrice": null,
      "recommendId": null,
      "limitedTimes": [
        {
          "day": 0,
          "price": 999,
          "clothVoucherPrice": 100
        }
      ],
      "discountPrices": null,
      "occupyPosition": [
        14
      ],
      "releaseTime": null,
      "isActivity": 0,
      "activityFlag": null,
      "onSell": 1,
      "iosOnline": 1,
      "publishRegion": "regionALL",
      "gameId": null,
      "classify": "beishi",
      "discountRate": null,
      "discountRemainingTime": null,
      "jumpLink": null,
      "quality": 2,
      "minVipLevel": 0,
      "resourceInfo": null,
      "isWeekFree": 0,
      "sort": null,
      "remainingDays": null
    }
  ],
  "other": null
    };

    // Sending the response
    res.json(gameData);
});

app.post('/user/api/v1/user/password/modify', async (req, res) => {
    // Extract user ID and access token from request headers
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if access token and user ID are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the decoded user ID matches the provided user ID
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Find the user by user ID
            const user = await User.findById(userId);
            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            // Check if the old password matches
            if (user.password !== req.body.oldPassword) {
                return res.status(400).json({ message: 'Old password is incorrect.' });
            }

            // Check if new password and confirm password match
            if (req.body.newPassword !== req.body.confirmPassword) {
                return res.status(400).json({ message: 'New password and confirm password do not match.' });
            }

            // Update the user's password
            user.password = req.body.newPassword;
            await user.save();

            // Return success response
            res.json({ code: 1, message: 'SUCCESS' });
        });
    } catch (error) {
        console.error('Error updating password:', error);
        res.status(500).json({ message: 'Error updating password.' });
    }
});

app.post('/clan/api/v1/clan/tribe', async (req, res) => {
    const accessToken = req.headers['access-token'];
    const userId = req.headers['userid'];

    // Check if access token and user ID are provided
    if (!accessToken || !userId) {
        return res.status(400).json({ message: 'Access-Token and userId headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the decoded user ID matches the provided user ID
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Retrieve user from the database to get gold currency
            const user = await User.findById(userId);

            // Check if the user exists and has enough gold currency
            if (!user || user.gold < 8000) {
                return res.status(200).json({
                    code: 5006,
                    message: 'gold insufficient',
                    data: null,
                    other: null
                });
            }

            // Generate a random clan ID with 4 digits
            const clanId = Math.floor(1000 + Math.random() * 9000);

            // Create a new clan document with ownerId set to userId from headers
            const newClan = new ClanDB({
                clanId: clanId,
                ownerId: userId,
                name: req.body.name,
                headPic: "http://staticgs.sandboxol.com/sandbox/avatar/1710597820739694.jpg",
                tags: "[Ultra]",
                details: req.body.details,
                experience: 0,
                level: 1,
                role: 20,
                freeVerify: 0,
                region: null
            });

            // Save the new clan document to the ClanDB collection
            await newClan.save();

            // Deduct 8000 gold currency from the user's account (assuming you have a function to update the user's gold currency in the database)

            // Respond with success message and clan data
            res.status(200).json({
                code: 1,
                message: 'SUCCESS',
                data: newClan,
                other: null
            });
        });
    } catch (error) {
        console.error('Error creating clan:', error);
        res.status(500).json({ message: 'Error creating clan.' });
    }
});

app.get('/decoration/api/v1/vip/decorations/users/3', (req, res) => {
    const responseData = {
"code": 1,
  "message": "SUCCESS",
  "data": [],
  "other": null
    };

    // Sending the response
    res.json(responseData);
});

app.put('/decoration/api/v1/decorations/using/999999999', (req, res) => {
    const responseData = {
        "code": 1,
        "message": "SUCCESS",
        "data": {
            "id": 304,
            "typeId": 14,
            "camera": "top",
            "name": "Count Pumpkin Cloak",
            "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_wing.14.custom_wing.1571738201053.14",
            "status": 1,
            "sex": 0,
            "tag": [],
            "resourceId": "custom_wing.14",
            "details": "Count Pumpkin Cloak",
            "expire": 0,
            "type": 0,
            "clanLevel": 0,
            "vip": 0,
            "occupyPosition": [
                11
            ],
            "buyTime": 1670605903000,
            "isNew": 0,
            "releaseTime": null,
            "currency": 1,
            "suitId": null,
            "isActivity": 0,
            "activityFlag": "halloween",
            "jumpLink": "",
            "validDay": 0,
            "isWholeSetSuit": 0,
            "compensateId": null,
            "compensateNum": null,
            "publishRegion": "regionALL",
            "gameId": null,
            "classify": "fashi",
            "quality": 2,
            "isWeekFree": 0,
            "minVipLevel": 0,
            "evolutionLevel": 0,
            "resourceInfo": null,
            "signature": null,
            "signatureShow": null,
            "colorfulNickName": null
        },
        "other": null
    };

    // Sending the response
    res.json(responseData);
});

app.delete('/decoration/api/v1/decorations/using/999999999', (req, res) => {
    const responseData = {
        "code": 1,
        "message": "SUCCESS",
        "data": {
            "id": 304,
            "typeId": 14,
            "camera": "top",
            "name": "Count Pumpkin Cloak",
            "iconUrl": "http://staticgs.sandboxol.com/sandbox/dresses/iconscustom_wing.14.custom_wing.1571738201053.14",
            "status": 1,
            "sex": 0,
            "tag": [],
            "resourceId": "custom_wing.14",
            "details": "Count Pumpkin Cloak",
            "expire": 0,
            "type": 0,
            "clanLevel": 0,
            "vip": 0,
            "occupyPosition": [
                11
            ],
            "buyTime": 1670605903000,
            "isNew": 0,
            "releaseTime": null,
            "currency": 1,
            "suitId": null,
            "isActivity": 0,
            "activityFlag": "halloween",
            "jumpLink": "",
            "validDay": 0,
            "isWholeSetSuit": 0,
            "compensateId": null,
            "compensateNum": null,
            "publishRegion": "regionALL",
            "gameId": null,
            "classify": "fashi",
            "quality": 2,
            "isWeekFree": 0,
            "minVipLevel": 0,
            "evolutionLevel": 0,
            "resourceInfo": null,
            "signature": null,
            "signatureShow": null,
            "colorfulNickName": null
        },
        "other": null
    };

    // Sending the response
    res.json(responseData);
});
app.post('/upload/avatar5', async (req, res) => {
  try {
    const { id, typeId, camera, name, iconUrl, resourceId, details, forId } = req.body;

    // Cate a new avatar document
    const newAvatar = new Avatar5({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      forId,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ message: 'Avatar uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});

app.post('/upload/shop1', async (req, res) => {
  try {
    const { id, typeId, camera, name, iconUrl, resourceId, details, price, currency } = req.body;

    // Cate a new avatar document
    const newAvatar = new Shop({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      price,
      currency,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ message: 'Avatar uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});

app.post('/upload/avatar4', async (req, res) => {
  try {
    const { id, typeId, camera, name, iconUrl, resourceId, details, forId } = req.body;

    // Cate a new avatar document
    const newAvatar = new Avatar4({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      forId,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ message: 'Avatar uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});

app.post('/upload/avatar3', async (req, res) => {
  try {
    const { id, typeId, camera, name, iconUrl, resourceId, details, forId } = req.body;

    // Cate a new avatar document
    const newAvatar = new Avatar3({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      forId,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ message: 'Avatar uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});

app.get('/decoration/api/v1/decorations/5', async (req, res) => {
  
const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }
  
  try {
    // Fetch all avatars from the database
    let avatars = await Avatar5.find();

    // Map the fetched avatars to the desid sponse format
    const responseData = avatars.map(avatar => ({
      id: avatar.id,
      typeId: avatar.typeId,
      camera: avatar.camera,
      name: avatar.name,
      iconUrl: avatar.iconUrl,
      status: 0,
      sex: 0,
      tag: [],
      resourceId: avatar.resourceId,
      details: avatar.details,
      expi: 0,
      type: 0,
      clanLevel: 0,
      vip: 0,
      occupyPosition: [12]
    }));

    res.status(200).json({
                code: 1,
                message: 'SUCCESS',
        data: responseData,
                    other: null
            });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

app.get('/decoration/api/v1/decorations/7', async (req, res) => {
  
const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }
  
  try {
    // Fetch all avatars from the database
    let avatars = await Avatar4.find();

    // Map the fetched avatars to the desid sponse format
    const responseData = avatars.map(avatar => ({
      id: avatar.id,
      typeId: avatar.typeId,
      camera: avatar.camera,
      name: avatar.name,
      iconUrl: avatar.iconUrl,
      status: 0,
      sex: 0,
      tag: [],
      resourceId: avatar.resourceId,
      details: avatar.details,
      expi: 0,
      type: 0,
      clanLevel: 0,
      vip: 0,
      occupyPosition: [12]
    }));

    res.status(200).json({
                code: 1,
                message: 'SUCCESS',
        data: responseData,
        other: null
            });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

app.get('/decoration/api/v1/decorations/2', async (req, res) => {
  
  const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }
  
  try {
    // Fetch all avatars from the database
    let avatars = await Avatar3.find();

    // Map the fetched avatars to the desid sponse format
    const responseData = avatars.map(avatar => ({
      id: avatar.id,
      typeId: avatar.typeId,
      camera: avatar.camera,
      name: avatar.name,
      iconUrl: avatar.iconUrl,
      status: 0,
      sex: 0,
      tag: [],
      resourceId: avatar.resourceId,
      details: avatar.details,
      expie: 0,
      type: 0,
      clanLevel: 0,
      vip: 0,
      occupyPosition: [12]
    }));

    res.status(200).json({
                code: 1,
                message: 'SUCCESS',
        data: responseData,
        other: null
            });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

// Get Avatars API
app.get('/decoration/api/v1/decorations/3', async (req, res) => {
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (err, decoded) => {
            if (err) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the decoded user ID matches the provided user ID
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Fetch all avatars from Avatar collection with forId similar to userId
            let avatars = await Avatar.find();

            // Map the fetched avatars to the desired response format
            const responseData = avatars.map(avatar => ({
                id: avatar.id,
                typeId: avatar.typeId,
                camera: avatar.camera,
                name: avatar.name,
                iconUrl: avatar.iconUrl,
                status: 0,
                sex: 0,
                tag: [],
                resourceId: avatar.resourceId,
                details: avatar.details,
                expireDate: 0,
                type: 0,
                clanLevel: 0,
                vip: 0,
                occupyPosition: [12]
            }));

            res.status(200).json({
                code: 1,
                message: 'SUCCESS',
        data: responseData,
        other: null
            });
        });
    } catch (error) {
        console.error('Error fetching avatars:', error);
        res.status(500).json({ message: 'Error fetching avatars.' });
    }
});


app.get('/decoration/api/v1/vip/decorations/users/3', (req, res) => {
    const sponseData = {
"code": 1,
  "message": "SUCCESS",
  "data": [],
  "other": null
    };

    // Sending the sponse
    res.json(sponseData);
});

app.get('/decoration/api/v1/decorations/1', async (req, res) => {
  const userId = req.headers['userid'];
  const accessToken = req.headers['access-token'];

  // Check if userId and accessToken are provided
  if (!userId || !accessToken) {
    return res.status(400).json({ message: 'UserId and Access-Token headers are required.' });
  }

  try {
    // Verify the access token
    jwt.verify(accessToken, JWT_SECRET, async (err, decoded) => {
      if (err) {
        console.error('Access token verification failed:', err);
        return res.status(401).json({ message: 'Invalid Access-Token.' });
      }

      // Check if the decoded user ID matches the provided user ID
      if (decoded.userId !== userId) {
        return res.status(403).json({ message: 'Access-Token does not match userId.' });
      }

      // Query the user database to check if getSkins is true
      const user = await User.findOne({ userId: userId });
      if (!user) {
        return res.json({ code: 1, message: 'SUCCESS', data: [] });
      }

      const getSkins = user.getSkins !== undefined ? user.getSkins : true;

      // If getSkins is false, return an empty array
      if (!getSkins) {
        return res.json({ code: 1, message: 'SUCCESS', data: [] });
      }

      // Fetch all avatars from the database
      let avatars = await Avatar2.find();

      // Sort the avatars based on camera and the presence of the name "shoes"
      avatars.sort((a, b) => {
        // Sort by camera: top first, then bottom
        if (a.camera === 'top' && b.camera === 'bottom') return -1;
        if (a.camera === 'bottom' && b.camera === 'top') return 1;

        // If both are of the same camera type or both are different, sort by name
        if (a.name.includes('shoes') && !b.name.includes('shoes')) return 1;
        if (!a.name.includes('shoes') && b.name.includes('shoes')) return -1;

        // If neither avatar has "shoes" in their name or they have the same camera type, keep the original order
        return 0;
      });
      // Map the fetched and sorted avatars to the desired response format
      const responseData = avatars.map(avatar => ({
        id: avatar.id,
        typeId: avatar.typeId,
        camera: avatar.camera,
        name: avatar.name,
        iconUrl: avatar.iconUrl,
        status: 0,
        sex: 0,
        tag: [],
        resourceId: avatar.resourceId,
        details: avatar.details,
        expire: 0,
        type: 0,
        clanLevel: 0,
        vip: 0,
        occupyPosition: [12]
      }));

      res.status(200).json({
        code: 1,
        message: 'SUCCESS',
        data: responseData,
        other: null
      });
    });
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ message: 'Error fetching avatars.' });
  }
});

app.get('/decoration/api/v1/vip/decorations/users/1', (req, res) => {
    const sponseData = {
"code": 1,
  "message": "SUCCESS",
  "data": [],
  "other": null
    };

    // Sending the sponse
    res.json(sponseData);
});

app.post('/upload/avatar2', async (req, res) => {
  try {
    const { id, typeId, camera, name, iconUrl, resourceId, details, forId } = req.body;

    // Cate a new avatar document
    const newAvatar = new Avatar2({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      forId,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ message: 'Avatar uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});

// Upload Avatar API
app.post('/upload/avatar', async (req, res) => {
  const { id, typeId, camera, name, iconUrl, resourceId, details, forId } = req.body;
  
  try {
    
    // Cate a new avatar document
    const newAvatar = new Avatar({
      id,
      typeId,
      camera,
      name,
      iconUrl,
      resourceId,
      details,
      forId,
    });

    // Save the avatar to the database
    await newAvatar.save();

    res.json({ code: 1, message: 'Avatar uploaded successfully.', data: newAvatar });
  } catch (error) {
    console.error('Error uploading avatar:', error);
    res.status(500).json({ message: 'Error uploading avatar.' });
  }
});



// Get equipped avatar
app.get('/decoration/api/v1/decorations/using', async (req, res) => {
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (err, decoded) => {
            if (err) {
                console.error('Access token verification failed:', err);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the decoded user ID matches the provided user ID
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Query the database for all equipped avatars of the user
            const equippedAvatars = await EquippedAvatar.find({ userId: userId });

            // If no equipped avatars found, return error response
            if (!equippedAvatars || equippedAvatars.length === 0) {
                return res.status(404).json({ message: 'Equipped avatars not found for the user.' });
            }

            // Construct the response data with skin info
            const responseData = equippedAvatars.map(equippedAvatar => ({
                id: equippedAvatar.avatarId,
                typeId: equippedAvatar.avatarTypeId,
                camera: equippedAvatar.avatarCamera,
                name: equippedAvatar.avatarName,
                iconUrl: equippedAvatar.avatarIconUrl,
                status: 1,
                sex: 0,
                tag: [],
                resourceId: equippedAvatar.avatarResourceId,
                details: equippedAvatar.avatarDetails,
                type: 0,
                clanLevel: 0,
                vip: 0,
                occupyPosition: [7],
                buyTime: 1670605738000,
                isNew: 0,
                releaseTime: null,
                currency: 2,
                suitId: null,
                isActivity: 0,
                activityFlag: null,
                jumpLink: null,
                validDay: 0,
                isWholeSetSuit: 0,
                compensateId: null,
                compensateNum: null,
                publishRegion: "regionALL",
                gameId: null,
                classify: "beijing",
                quality: 4,
                isWeekFree: 0,
                minVipLevel: 0,
                evolutionLevel: 0,
                resourceInfo: null,
                signature: null,
                signatureShow: null,
                colorfulNickName: null
            }));

            // Sending the response with code, message, and data keys
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (err) {
        console.error('Error fetching equipped avatars:', err);
        res.status(500).json({ message: 'Error fetching equipped avatars.' });
    }
});


// Equipping avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
// Updating equipped avatar
app.put('/decoration/api/v1/decorations/using/:avatarId', async (req, res) => {
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];
    const avatarId = req.params.avatarId;

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }

    try {
        // Verify the access token
        const decoded = jwt.verify(accessToken, JWT_SECRET);

        // Check if the decoded user ID matches the provided user ID
        if (decoded.userId !== userId) {
            return res.status(403).json({ message: 'Access-Token does not match userId.' });
        }

        // Find the avatar in any of the databases
        let avatar = await Avatar.findOne({ id: avatarId });
        if (!avatar) {
            const avatarCollections = [Avatar2, Avatar3, Avatar4, Avatar5];
            for (const collection of avatarCollections) {
                avatar = await collection.findOne({ id: avatarId });
                if (avatar) break;
            }
        }

        // If the avatar is not found, return error response
        if (!avatar) {
            return res.status(404).json({ message: 'Avatar not found.' });
        }

        // Keywords to determine category
        const categoryMap = {
            'top': ['top', 'shirt'],
            'pants': ['pants', 'bottom'],
            'shoes': ['shoes', 'footwear'],
            'back': ['back', 'backpack'],
            'hair': ['hair'],
            'jacket': ['jacket'],
            'leather': ['leather'],
            'wings': ['wings'],
            'head': ['head', 'hat'],
            'scarf': ['scarf'],
            'cloak': ['cloak'],
            'cape': ['cape'],
            'coat': ['coat'],
            'glasses': ['glasses', 'eyewear'],
            'crown': ['crown'],
            'emote': ['emote'],
            'view': ['view'],
            'idle': ['idle']
        };

        let category = '';
        for (const [cat, keywords] of Object.entries(categoryMap)) {
            if (keywords.some(keyword => avatar.name.toLowerCase().includes(keyword))) {
                category = cat;
                break;
            }
        }

        // If category is not found, return error response
        if (!category) {
            return res.status(400).json({ message: 'Invalid avatar category.' });
        }

        // Find and delete existing avatar with the same category
        await EquippedAvatar.deleteOne({ userId: userId, avatarName: { $regex: category, $options: 'i' } });

        // Save the equipped avatar to the user's database
        const equippedAvatar = new EquippedAvatar({
            userId: userId,
            avatarId: avatar.id,
            avatarTypeId: avatar.typeId,
            avatarCamera: avatar.camera,
            avatarName: avatar.name,
            avatarIconUrl: avatar.iconUrl,
            avatarResourceId: avatar.resourceId,
            avatarDetails: avatar.details,
            avatarPrice: avatar.price,
            avatarCurrency: avatar.currency
        });
        await equippedAvatar.save();

        // Construct the response data
        const responseData = {
            id: avatar.id,
            typeId: avatar.typeId,
            camera: avatar.camera,
            name: avatar.name,
            iconUrl: avatar.iconUrl,
            status: 0,
            sex: 0,
            tag: [],
            resourceId: avatar.resourceId,
            details: avatar.details
        };

        // Sending the response
        res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
    } catch (err) {
        console.error('Error updating avatar usage:', err);
        res.status(500).json({ message: 'Error updating avatar usage.' });
    }
});

// moving equipped avatar
app.delete('/decoration/api/v1/decorations/using/:avatarId', async (req, res) => {
    const userId = req.headers['userid'];
    const accessToken = req.headers['access-token'];
    const avatarId = req.params.avatarId;

    // Check if userid and access token are provided
    if (!userId || !accessToken) {
        return res.status(400).json({ message: 'Userid and Access-Token headers are required.' });
    }

    try {
        // Verify the access token
        jwt.verify(accessToken, JWT_SECRET, async (error, decoded) => {
            if (error) {
                console.error('Access token verification failed:', error);
                return res.status(401).json({ message: 'Invalid Access-Token.' });
            }

            // Check if the decoded user ID matches the provided user ID
            if (decoded.userId !== userId) {
                return res.status(403).json({ message: 'Access-Token does not match userId.' });
            }

            // Find and remove the equipped avatar from the database
            const deletedAvatar = await EquippedAvatar.findOneAndDelete({ userId: userId, avatarId: avatarId });

            // If the equipped avatar was not found, return error response
            if (!deletedAvatar) {
                return res.status(404).json({ message: 'Equipped avatar not found.' });
            }

            // Construct the response data
            const responseData = {
                id: deletedAvatar.avatarId,
                typeId: deletedAvatar.avatarTypeId,
                camera: deletedAvatar.avatarCamera,
                name: deletedAvatar.avatarName,
                iconUrl: deletedAvatar.avatarIconUrl,
                resourceId: deletedAvatar.avatarResourceId,
                details: deletedAvatar.avatarDetails,
                expire: 0,
                type: 0,
                clanLevel: 0,
                vip: 0,
                occupyPosition: [11], // Assuming the position is always 11 for using
                buyTime: 1670605903000,
                isNew: 0,
                leaseTime: null,
                currency: 1,
                suitId: null,
                isActivity: 0,
                activityFlag: 'halloween',
                jumpLink: '',
                validDay: 0,
                isWholeSetSuit: 0,
                compensateId: null,
                compensateNum: null,
                region: 'gionALL',
                gameId: null,
                classify: 'fashi',
                quality: 2,
                isWeekFee: 0,
                minVipLevel: 0,
                evolutionLevel: 0,
                sourceInfo: null,
                signature: null,
                signatureShow: null,
                colorfulNickName: null
            };

            // Sending the response
            res.status(200).json({ code: 1, message: 'SUCCESS', data: responseData });
        });
    } catch (error) {
        console.error('Error moving equipped avatar:', error);
        res.status(500).json({ message: 'Error moving equipped avatar.' });
    }
});

app.listen(PORT, IP_ADDRESS, () => {
  console.log(`Server is running on http://${IP_ADDRESS}:${PORT}`);
});
